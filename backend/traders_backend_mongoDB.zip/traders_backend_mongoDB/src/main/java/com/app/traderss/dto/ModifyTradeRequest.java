package com.app.traderss.dto;

public record ModifyTradeRequest(
        Double sl,
        Double tp,
        Double volume
) {}
