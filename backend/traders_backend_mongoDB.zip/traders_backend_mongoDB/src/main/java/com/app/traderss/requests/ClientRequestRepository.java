package com.app.traderss.requests;

import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ClientRequestRepository extends MongoRepository<ClientRequest, String> {
    List<ClientRequest> findByUserIdOrderByCreatedAtDesc(String userId);
    List<ClientRequest> findByCategoryOrderByCreatedAtDesc(String category);
}
