package com.app.traderss.trades;

import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface OpenTradeRepository extends MongoRepository<OpenTrade, String> {
    Optional<OpenTrade> findByUserIdAndId(String userId, String id);
List<OpenTrade> findByUserIdAndStatus(String userId, OrderStatus status);
    List<OpenTrade> findBySymbol(String symbol);
    List<OpenTrade> findBySymbolAndStatus(String symbol, OrderStatus status);
    List<OpenTrade> findByStatus(OrderStatus status);
    List<OpenTrade> findByUserId(String userId);

}
