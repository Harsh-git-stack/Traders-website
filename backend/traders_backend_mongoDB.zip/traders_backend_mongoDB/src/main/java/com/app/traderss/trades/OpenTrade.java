package com.app.traderss.trades;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Optional;

@Getter
@Setter
@Document(collection = "open_trades")
@JsonInclude(JsonInclude.Include.ALWAYS)
public class OpenTrade {

    @Id
    private String id;

    @Indexed
    private String userId;
    @Indexed
    private String symbol;
    private String type; // buy / sell
    private Double volume;
    private Double openPrice;
    private Double sl;
    private Double tp;
    private double profit;
    private String time;
    private OrderStatus status; // OPEN / CLOSED / PENDING
    private OrderType orderType; // BUY, BUY_LIMIT, etc.

    private Double triggerPrice; // STOP price
    private Double limitPrice; // LIMIT price (for stop-limit)

    // New MT5 Fields
    private long magicNumber = 0; // EA ID
    private String comment = ""; // Order note
    private String expiration; // ISO date for pendings

    private double accumulatedSwap = 0.0; // NEW: Running swap
    private double accumulatedCommission = 0.0; // NEW: Running commission
    private Integer tradeCount = 1; //safer for backend as treats old values null

    @JsonProperty // NEW: Explicitly include
    private Double pipSize;
    @JsonProperty // NEW
    private Double pipValuePerLot;
    @JsonProperty // NEW
    private Double pipValue; // pipValuePerLot * volume

}