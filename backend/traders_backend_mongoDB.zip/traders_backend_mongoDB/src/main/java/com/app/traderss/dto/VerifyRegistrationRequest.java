package com.app.traderss.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record VerifyRegistrationRequest(
        @Email @NotBlank String email,
        @NotBlank String otp
) {}
