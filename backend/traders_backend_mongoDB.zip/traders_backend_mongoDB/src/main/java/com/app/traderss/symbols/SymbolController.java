package com.app.traderss.symbols;

import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.domain.PageImpl;


import java.util.List;

@RestController
@RequestMapping("/api/symbols")
public class SymbolController {

    private final SymbolRepository repo;
    private final MongoTemplate mongo;

    public SymbolController(SymbolRepository repo, MongoTemplate mongo) {
        this.repo = repo;
        this.mongo = mongo;
    }

    @GetMapping("/{symbol}/spec")
    public ResponseEntity<?> getSpec(@PathVariable String symbol) {
        return repo.findById(symbol.toUpperCase())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public Page<SymbolSpec> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @RequestParam(required = false) String type) {

        Pageable p = PageRequest.of(page, size, Sort.by("id"));
        if (type != null && !type.isBlank())
            return repo.findByType(type.toUpperCase(), p);

        return repo.findAll(p);
    }

    @GetMapping("/search")
    public Page<SymbolSpec> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {

        String regex = "(?i).*" + q + ".*";
        Query query = new Query(new Criteria().orOperator(
                Criteria.where("_id").regex(regex),
                Criteria.where("name").regex(regex)
        )).with(PageRequest.of(page, size));

        var found = mongo.find(query, SymbolSpec.class);
        long total = mongo.count(query.limit(-1).skip(-1), SymbolSpec.class);

        return new PageImpl<>(found, PageRequest.of(page, size), total);
    }
}


