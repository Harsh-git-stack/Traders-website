package com.app.traderss.auth;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;

@Service
public class EmailOtpService {

    private final ObjectProvider<JavaMailSender> mailSenderProvider;
    private final SecureRandom secureRandom = new SecureRandom();

    @Value("${app.otp.mail-enabled:false}")
    private boolean mailEnabled;

    @Value("${spring.mail.username:no-reply@nexfordmarket.local}")
    private String fromEmail;

    public EmailOtpService(ObjectProvider<JavaMailSender> mailSenderProvider) {
        this.mailSenderProvider = mailSenderProvider;
    }

    public String generateOtp() {
        return String.valueOf(100000 + secureRandom.nextInt(900000));
    }

    public boolean isMailEnabled() {
        return mailEnabled;
    }

    public void sendSignupOtp(String toEmail, String name, String otp) {
        if (!mailEnabled) {
            System.out.println("Signup OTP for " + toEmail + ": " + otp);
            return;
        }

        JavaMailSender mailSender = mailSenderProvider.getIfAvailable();
        if (mailSender == null) {
            throw new IllegalStateException("SMTP is enabled, but JavaMailSender is not configured");
        }

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(toEmail);
        message.setSubject("Your NexfordMarket signup OTP");
        message.setText("""
                Hi %s,

                Your NexfordMarket verification code is %s.
                This code expires in 10 minutes.

                If you did not request this, you can ignore this email.
                """.formatted(name, otp));

        mailSender.send(message);
    }

    public void sendPasswordResetOtp(String toEmail, String otp) {
        if (!mailEnabled) {
            System.out.println("Password reset OTP for " + toEmail + ": " + otp);
            return;
        }

        JavaMailSender mailSender = mailSenderProvider.getIfAvailable();
        if (mailSender == null) {
            throw new IllegalStateException("SMTP is enabled, but JavaMailSender is not configured");
        }

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(toEmail);
        message.setSubject("Your NexfordMarket password reset OTP");
        message.setText("""
                Hi,

                Your NexfordMarket password reset code is %s.
                This code expires soon.

                If you did not request this, you can ignore this email.
                """.formatted(otp));

        mailSender.send(message);
    }
}
