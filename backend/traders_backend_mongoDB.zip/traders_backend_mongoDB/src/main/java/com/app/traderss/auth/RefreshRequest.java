package com.app.traderss.auth;

// NEW DTO for refresh (in dto package)
public class RefreshRequest {
    private String oldToken;

    public String getOldToken() {
        return oldToken;
    }

    public void setOldToken(String oldToken) {
        this.oldToken = oldToken;
    }
}
