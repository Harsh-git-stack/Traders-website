package com.app.traderss.trades;

import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;
import java.util.Optional;

public interface ClosedTradeRepository extends MongoRepository<ClosedTrade, String> {
    List<ClosedTrade> findByUserId(String userId);
    Optional<ClosedTrade> findByUserIdAndId(String userId, String id);
}
