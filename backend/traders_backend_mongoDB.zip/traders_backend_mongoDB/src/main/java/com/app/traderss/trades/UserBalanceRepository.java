package com.app.traderss.trades;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import java.util.Optional;

public interface UserBalanceRepository extends MongoRepository<UserBalance, String> {
    @Query("{ 'userId': ?0 }")
    Optional<UserBalance> findByUserId(String userId);

    // For balance value directly
    default Optional<Double> findBalanceByUserId(String userId) {
        return findByUserId(userId).map(UserBalance::getBalance);
    }

    default Optional<Double> findCreditByUserId(String userId) {
        return findByUserId(userId).map(UserBalance::getCredit);
    }
}