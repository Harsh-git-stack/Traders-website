package com.app.traderss.dto;

import com.app.traderss.user.User;

public class LoginResponse {
    public String token;
    public User user;

    public LoginResponse(String token, User user) {
        this.token = token;
        this.user = user;
    }
}
