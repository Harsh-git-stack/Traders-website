package com.app.traderss.trades;

public enum OrderType {
    BUY,
    SELL,

    BUY_LIMIT,
    SELL_LIMIT,

    BUY_STOP,
    SELL_STOP,

    BUY_STOP_LIMIT,
    SELL_STOP_LIMIT
}
