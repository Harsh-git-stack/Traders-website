package com.app.traderss.trades.kafka;

import com.app.traderss.trades.TradeService;
import com.app.traderss.trades.OpenTrade;
import com.app.traderss.trades.OpenTradeRepository;
import com.app.traderss.trades.OrderStatus;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;


@Component
public class CloseCommandListener {

    private final TradeService tradeService;
    private final OpenTradeRepository openRepo;

    public CloseCommandListener(TradeService tradeService,
                                OpenTradeRepository openRepo) {
        this.tradeService = tradeService;
        this.openRepo = openRepo;
    }

  @KafkaListener(
    topics = "trade.close",
    containerFactory = "closeKafkaListenerContainerFactory"
)
    public void handleCloseCommand(CloseCommand cmd) {

        OpenTrade trade = openRepo.findById(cmd.getTradeId())
                .orElse(null);

        if (trade == null ||
            trade.getStatus() != OrderStatus.OPEN) {
            return;
        }

        tradeService.closeTradeAtomically(
                trade,
                cmd.getClosePrice(),
                cmd.getReason()
        );

        System.out.println("Kafka close executed: "
                + cmd.getTradeId());
    }
}
