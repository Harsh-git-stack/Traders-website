package com.app.traderss.symbols;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;

@Document(collection = "symbols")
public class SymbolDoc {
    @Id
    private String symbol;
    private String type;     // Forex | Crypto | Index | Stock etc.
    private String base;
    private String quote;
    private String name;
    private Integer precision;
    private Double pip;
    private String status;
    private String source;
    private Instant lastUpdated;

    // new field: spread as String with default "0"
    private String spread = "0";

    public SymbolDoc() {
        this.lastUpdated = Instant.now();
        this.status = "active";
        this.spread = "0";
    }

    // minimal constructor
    public SymbolDoc(String symbol, String type, String name, Integer precision, Double pip, String source) {
        this.symbol = symbol;
        this.type = type;
        this.name = name;
        if (symbol != null && symbol.length() >= 6) {
            this.base = symbol.substring(0,3);
            this.quote = symbol.substring(3);
        }
        this.precision = precision == null ? (symbol!=null && symbol.contains("JPY") ? 3 : 5) : precision;
        // FIXED: Use actual pip size (not tick size)
        this.pip = pip == null ? 1.0 / Math.pow(10, this.precision - 1) : pip;
        this.status = "active";
        this.source = source;
        this.lastUpdated = Instant.now();
        this.spread = "0"; // default
    }
    // getters & setters
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getBase() { return base; }
    public void setBase(String base) { this.base = base; }

    public String getQuote() { return quote; }
    public void setQuote(String quote) { this.quote = quote; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getPrecision() { return precision; }
    public void setPrecision(Integer precision) { this.precision = precision; }

    public Double getPip() { return pip; }
    public void setPip(Double pip) { this.pip = pip; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public Instant getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(Instant lastUpdated) { this.lastUpdated = lastUpdated; }

    public String getSpread() { return spread; }
    public void setSpread(String spread) { this.spread = spread; }
}