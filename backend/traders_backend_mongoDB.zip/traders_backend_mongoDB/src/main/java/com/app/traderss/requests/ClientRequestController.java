package com.app.traderss.requests;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@RestController
@RequestMapping("/api/client-requests")
public class ClientRequestController {

    private final ClientRequestRepository requestRepo;

    public ClientRequestController(ClientRequestRepository requestRepo) {
        this.requestRepo = requestRepo;
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody ClientRequestCreateRequest req, Authentication auth) {
        if (auth == null || auth.getPrincipal() == null) {
            return ResponseEntity.status(401).body(Map.of("message", "Login required"));
        }

        ClientRequest request = new ClientRequest();
        request.setUserId(String.valueOf(auth.getPrincipal()));
        request.setRequestType(req.requestType().trim());
        request.setCategory(resolveCategory(req.requestType()));
        request.setStatus("PENDING");
        request.setPayload(safePayload(req.payload()));
        request.setCreatedAt(Instant.now());
        request.setUpdatedAt(Instant.now());

        ClientRequest saved = requestRepo.save(request);
        return ResponseEntity.ok(Map.of(
                "message", req.requestType() + " request submitted.",
                "request", saved
        ));
    }

    @GetMapping("/mine")
    public ResponseEntity<?> mine(Authentication auth) {
        if (auth == null || auth.getPrincipal() == null) {
            return ResponseEntity.status(401).body(Map.of("message", "Login required"));
        }
        List<ClientRequest> requests = requestRepo.findByUserIdOrderByCreatedAtDesc(String.valueOf(auth.getPrincipal()));
        return ResponseEntity.ok(Map.of("requests", requests));
    }

    private String resolveCategory(String requestType) {
        String normalized = requestType == null ? "" : requestType.toLowerCase(Locale.ROOT);
        if (normalized.contains("withdraw")) return "WITHDRAW";
        if (normalized.contains("transfer")) return "TRANSFER";
        if (normalized.contains("deposit")) return "DEPOSIT";
        return "OTHER";
    }

    private Map<String, Object> safePayload(Map<String, Object> payload) {
        if (payload == null) return new LinkedHashMap<>();
        return new LinkedHashMap<>(payload);
    }
}
