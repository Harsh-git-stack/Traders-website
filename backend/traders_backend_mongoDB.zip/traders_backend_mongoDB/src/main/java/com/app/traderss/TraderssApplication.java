package com.app.traderss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@EnableScheduling
@SpringBootApplication
@EnableMethodSecurity(prePostEnabled = true)
public class TraderssApplication {

    public static void main(String[] args) {
        SpringApplication.run(TraderssApplication.class, args);
    }
    
}


