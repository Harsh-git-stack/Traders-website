package com.app.traderss.trades.kafka;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;

import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;

@Configuration
public class CloseKafkaConfig {

    @Bean
    public ConsumerFactory<String, CloseCommand> closeConsumerFactory(
            @Value("${spring.kafka.bootstrap-servers}") String servers) {

        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, servers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "trade-close-group");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);

        JsonDeserializer<CloseCommand> delegate =
                new JsonDeserializer<>(CloseCommand.class);
        
        delegate.addTrustedPackages("*");
delegate.ignoreTypeHeaders();
ErrorHandlingDeserializer<CloseCommand> valueDeserializer = new ErrorHandlingDeserializer<>(delegate);

        return new DefaultKafkaConsumerFactory<>(
                props,
                new StringDeserializer(),
                valueDeserializer
        );
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, CloseCommand>
    closeKafkaListenerContainerFactory(
            ConsumerFactory<String, CloseCommand> closeConsumerFactory) {

        ConcurrentKafkaListenerContainerFactory<String, CloseCommand> factory =
                new ConcurrentKafkaListenerContainerFactory<>();

        factory.setConsumerFactory(closeConsumerFactory);
        return factory;
    }
}