package com.app.traderss.dto;

public record AccountResponse(
        double balance,
        double equity,
        double margin,
        double freeMargin,
        double marginLevel,
        double swap, 
        double commission, 
        double floatingProfit) {
}
