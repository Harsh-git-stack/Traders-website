package com.app.traderss.trades;

import java.util.List;

public record TradesResponse(
        List<OpenTrade> open,
        List<ClosedTrade> closed
) {}
