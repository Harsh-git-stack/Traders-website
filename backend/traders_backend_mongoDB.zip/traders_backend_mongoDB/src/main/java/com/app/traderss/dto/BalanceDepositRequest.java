package com.app.traderss.dto;

public record BalanceDepositRequest(String userId, double amount, String reason) {}
