package com.app.traderss.symbols;

import org.springframework.boot.CommandLineRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class SymbolBootstrap implements CommandLineRunner {

    private final MongoTemplate mongoTemplate;
    private final MassiveSymbolSyncService syncService;

    public SymbolBootstrap(MongoTemplate mongoTemplate, MassiveSymbolSyncService syncService) {
        this.mongoTemplate = mongoTemplate;
        this.syncService = syncService;
    }

    private int inferDigits(String symbol) {
        if (symbol == null)
            return 5;
        String s = symbol.toUpperCase();

        if (s.startsWith("XAU"))
            return 2;
        if (s.startsWith("XAG"))
            return 3;
        if (s.contains("JPY"))
            return 3;
        return 5;
    }

    private double inferPipSize(String symbol) {
        if (symbol == null)
            return 0.0001;
        String s = symbol.toUpperCase();

        if (s.startsWith("XAU"))
            return 0.01;
        if (s.startsWith("XAG"))
            return 0.001;
        if (s.contains("JPY"))
            return 0.01;
        return 0.0001;
    }

    @Override
    public void run(String... args) throws Exception {
        List<SymbolSpec> all = mongoTemplate.findAll(SymbolSpec.class, "symbols");

        int migrated = 0;
        for (SymbolSpec s : all) {
            boolean changed = false;

            if (s.getDescription() == null) {
                s.setDescription(s.getName());
                changed = true;
            }
            if (s.getExchange() == null) {
                s.setExchange("XCCY");
                changed = true;
            }
            if (s.getSector() == null) {
                s.setSector("Currency");
                changed = true;
            }
            if (s.getId() != null) {
                int expectedDigits = inferDigits(s.getId());
                double expectedPipSize = inferPipSize(s.getId());

                if (s.getDigits() != expectedDigits) {
                    s.setDigits(expectedDigits);
                    changed = true;
                }

                if (s.getPipSize() != expectedPipSize) {
                    s.setPipSize(expectedPipSize);
                    changed = true;
                }
            }
            if (s.getSpreadType() == null) {
                s.setSpreadType("Floating");
                changed = true;
            }
            if (s.getStopLevels() == 0) {
                s.setStopLevels(0);
                changed = true;
            }
            if (s.getMarginCurrency() == null && s.getId() != null && s.getId().length() >= 3) {
                s.setMarginCurrency(s.getId().substring(0, 3));
                changed = true;
            }
            if (s.getProfitCurrency() == null && s.getId() != null && s.getId().length() >= 6) {
                s.setProfitCurrency(s.getId().substring(3, 6));
                changed = true;
            }
            if (s.getCalculation() == null) {
                s.setCalculation("Forex");
                changed = true;
            }
            if (s.getTrade() == null) {
                s.setTrade("Full access");
                changed = true;
            }
            if (s.getChartMode() == null) {
                s.setChartMode("By bid price");
                changed = true;
            }
            if (s.getExecution() == null) {
                s.setExecution("Market Execution");
                changed = true;
            }
            if (s.getGtcMode() == null) {
                s.setGtcMode("Good till cancelled");
                changed = true;
            }
            if (s.getFillPolicy() == null) {
                s.setFillPolicy("Fill or Kill");
                changed = true;
            }
            if (s.getExpiration() == null) {
                s.setExpiration("All");
                changed = true;
            }
            if (s.getOrders() == null) {
                s.setOrders("All");
                changed = true;
            }
            if (s.getMinimalVolume() == 0) {
                s.setMinimalVolume(0.01);
                changed = true;
            }
            if (s.getMaximalVolume() == 0) {
                s.setMaximalVolume(500);
                changed = true;
            }
            if (s.getVolumeStep() == 0) {
                s.setVolumeStep(0.01);
                changed = true;
            }
            if (s.getSwapType() == null) {
                s.setSwapType("In points");
                changed = true;
            }
            if (s.getSwapRates() == null) {
                s.setSwapRates(Map.of(
                        "monday", 1,
                        "tuesday", 1,
                        "wednesday", 3,
                        "thursday", 1,
                        "friday", 1));
                changed = true;
            }
            if (s.getQuotesSessions() == null) {
                s.setQuotesSessions(Map.of(
                        "monday", "00:00-24:00",
                        "tuesday", "00:00-24:00",
                        "wednesday", "00:00-24:00",
                        "thursday", "00:00-24:00",
                        "friday", "00:00-24:00"));
                changed = true;
            }
            if (s.getTradeSessions() == null) {
                s.setTradeSessions(Map.of(
                        "monday", "00:00-24:00",
                        "tuesday", "00:00-24:00",
                        "wednesday", "00:00-24:00",
                        "thursday", "00:00-24:00",
                        "friday", "00:00-24:00"));
                changed = true;
            }

            if (changed) {
                s.setLastUpdated(java.time.Instant.now());
                mongoTemplate.save(s, "symbols");
                migrated++;
            }
        }

        System.out.println("[SymbolBootstrap] migrated symbols: " + migrated);

        long count = mongoTemplate.getCollection("symbols").countDocuments();
        if (count == 0) {
            System.out.println("[SymbolBootstrap] symbols collection empty -> running initial Massive sync");
            syncService.syncMarket("fx", "FOREX");
            syncService.syncMarket("crypto", "CRYPTO");
        } else {
            System.out.println(
                    "[SymbolBootstrap] symbols already present (" + count + "), skipping initial Massive seed");
        }
    }
}