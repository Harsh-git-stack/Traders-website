
package com.app.traderss.dto;

public record CreditDepositRequest(String userId, double amount, String reason) {}
