package com.app.traderss.service;

import com.app.traderss.trades.OpenTrade;
import com.app.traderss.trades.OpenTradeRepository;
import com.app.traderss.trades.OrderStatus;
import com.app.traderss.symbols.SymbolRepository;
import com.app.traderss.symbols.SymbolSpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Swap accrual job.
 *
 * Fixes applied:
 *  - logs so you can confirm runs
 *  - uses Update.inc(...) to atomically increment accumulatedSwap
 *  - tolerant to missing SymbolSpec and different symbol formats
 *  - exposes a public method accrueAll() that you can call from a test REST endpoint
 */
@Service
public class SwapAccrualService {

    private static final Logger log = LoggerFactory.getLogger(SwapAccrualService.class);

    private final OpenTradeRepository openRepo;
    private final MongoTemplate mongoTemplate;
    private final SymbolRepository symbolRepo;

    // Example rates (points per day per 1 lot). Adjust as per your broker.
    // Ensure keys match trade.symbol format (e.g., "EURUSD","XAUUSD","BTCUSD").
    private Map<String, Map<String, Double>> swapRates = Map.of(
            "EURUSD", Map.of("buy", 0.5, "sell", -1.0),
            "BTCUSD", Map.of("buy", -10.0, "sell", 5.0),
            "XAUUSD", Map.of("buy", 0.1, "sell", -0.1)
    );

    public SwapAccrualService(OpenTradeRepository openRepo, MongoTemplate mongoTemplate, SymbolRepository symbolRepo) {
        this.openRepo = openRepo;
        this.mongoTemplate = mongoTemplate;
        this.symbolRepo = symbolRepo;
    }

    // Runs daily at midnight server time. For testing you can temporarily change to fixedRate.
    @Scheduled(cron = "0 0 0 * * ?")
    public void scheduledAccrue() {
        try {
            log.info("[SwapAccrualService] scheduledAccrue started");
            accrueAll();
            log.info("[SwapAccrualService] scheduledAccrue finished");
        } catch (Exception e) {
            log.error("[SwapAccrualService] error during scheduled accrue", e);
        }
    }


    /**
     * Public method that performs accrual: useful for tests or calling from a REST endpoint.
     */
    public void accrueAll() {
        List<OpenTrade> opens = openRepo.findByStatus(com.app.traderss.trades.OrderStatus.OPEN);
        log.info("[SwapAccrualService] found {} open trades", opens.size());

        for (OpenTrade trade : opens) {
            try {
                String rawSymbol = trade.getSymbol() == null ? "" : trade.getSymbol().replaceAll("[^A-Za-z0-9]", "").toUpperCase();
                String tradeType = trade.getType() == null ? "buy" : trade.getType().toLowerCase();
                double volume = trade.getVolume();

                double rate = 0.0;
                if (swapRates.containsKey(rawSymbol)) {
                    rate = swapRates.get(rawSymbol).getOrDefault(tradeType, 0.0);
                } else {
                    // try fallback: sometimes symbol stored as "EUR/USD" or with prefix
                    String alt = rawSymbol.replace("/", "").replace("_", "");
                    if (swapRates.containsKey(alt)) {
                        rate = swapRates.get(alt).getOrDefault(tradeType, 0.0);
                    }
                }

                // compute tickValuePerLot using SymbolSpec if available
                SymbolSpec spec = null;
                double tickValuePerLot = 0.0;
                try {
                    spec = symbolRepo.findById(rawSymbol).orElse(null);
                } catch (Exception e) {
                    // ignore repo lookup error — fallback below
                }

                if (spec != null && spec.getDigits() != 0) {
                    double tickSize = Math.pow(10, -spec.getDigits());
                    tickValuePerLot = spec.getContractSize() * tickSize;
                } else {
                    // fallback assumption
                    int digits = rawSymbol.contains("JPY") ? 3 : 5;
                    double tickSize = Math.pow(10, -digits);
                    double contractSize = 100000.0;
                    tickValuePerLot = contractSize * tickSize;
                }

                // dailySwap = lots * rate(points) * tickValuePerLot
                double dailySwap = volume * rate * tickValuePerLot;

                // If rate is zero skip but log
                if (Math.abs(dailySwap) < 1e-9) {
                    log.debug("[SwapAccrualService] dailySwap is ~0 for tradeId={} symbol={} rate={} volume={} -> skipping", trade.getId(), rawSymbol, rate, volume);
                    continue;
                }

                // Atomically increment accumulatedSwap on the DB side
                Query q = Query.query(Criteria.where("_id").is(trade.getId()));
                // Update u = new Update().inc("accumulatedSwap", dailySwap);
                Update u = new Update().inc("accumulatedSwap", dailySwap);
                mongoTemplate.updateFirst(q, u, OpenTrade.class);

                log.info("[SwapAccrualService] accrued tradeId={} symbol={} dailySwap={} (rate={}, tickValuePerLot={})",
                        trade.getId(), rawSymbol, dailySwap, rate, tickValuePerLot);
            } catch (Exception ex) {
                log.error("[SwapAccrualService] failed to accrue for tradeId=" + trade.getId(), ex);
            }
        }
    }
}
