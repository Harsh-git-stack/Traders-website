package com.app.traderss.trades;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "user_balances")
public class UserBalance {

    @Id
    private String userId;
    private double balance;
    private double credit;


    // Constructors
    public UserBalance() {}

    public UserBalance(String userId, double balance,double credit) {
        this.userId = userId;
        this.balance = balance;
        this.credit = credit;
    }

    // Getters/Setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }


    public double getCredit() { return credit; }
    public void setCredit(double credit) { this.credit = credit; }
    

}