package com.app.traderss.service;

import org.springframework.stereotype.Service;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

@Service
public class PriceService {
    private final Map<String, double[]> lastPrices = new ConcurrentHashMap<>();

    public void updatePrice(String symbol, double bid, double ask) {
        lastPrices.put(symbol, new double[]{bid, ask});
    }

    public double getBid(String symbol) {
        double[] prices = lastPrices.get(symbol);
        return prices != null ? prices[0] : Double.NaN;
    }

    public double getAsk(String symbol) {
        double[] prices = lastPrices.get(symbol);
        return prices != null ? prices[1] : Double.NaN;
    }
}