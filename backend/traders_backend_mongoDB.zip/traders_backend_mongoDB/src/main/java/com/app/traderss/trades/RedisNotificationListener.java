package com.app.traderss.trades;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
public class RedisNotificationListener implements MessageListener {

    private final SimpMessagingTemplate messagingTemplate;
    private final ObjectMapper mapper = new ObjectMapper();

    public RedisNotificationListener(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @Override
    public void onMessage(Message message, byte[] pattern) {
        if (message == null || message.getBody() == null) return;
        try {
            String payload = new String(message.getBody());
            JsonNode n = mapper.readTree(payload);
            String userId = n.has("user") ? n.get("user").asText() : null;

            if (userId != null) {
                // Re-emit locally using the same destinations we used in TradeService
                try {
                    messagingTemplate.convertAndSendToUser(userId, "/trades", mapper.readValue(payload, Object.class));
                } catch (Exception ex) {
                    // ignore per-instance errors
                }
                try {
                    messagingTemplate.convertAndSend("/topic/trades/" + userId, mapper.readValue(payload, Object.class));
                } catch (Exception ex) {}
                try {
                    messagingTemplate.convertAndSend("/topic/trades", mapper.readValue(payload, Object.class));
                } catch (Exception ex) {}
                try {
                    messagingTemplate.convertAndSend("/user/" + userId + "/trades", mapper.readValue(payload, Object.class));
                } catch (Exception ex) {}
            }
        } catch (Exception e) {
            System.err.println("[RedisNotificationListener] failed to handle message: " + e.getMessage());
        }
    }
}
