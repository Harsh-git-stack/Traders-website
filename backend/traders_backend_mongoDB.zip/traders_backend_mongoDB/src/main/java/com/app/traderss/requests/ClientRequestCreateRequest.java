package com.app.traderss.requests;

import jakarta.validation.constraints.NotBlank;

import java.util.Map;

public record ClientRequestCreateRequest(
        @NotBlank String requestType,
        Map<String, Object> payload
) {}
