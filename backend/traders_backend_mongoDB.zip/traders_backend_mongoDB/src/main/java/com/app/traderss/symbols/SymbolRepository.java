package com.app.traderss.symbols;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SymbolRepository extends MongoRepository<SymbolSpec, String> {
       Page<SymbolSpec> findByType(String type, Pageable pageable);
    // optional: find by name or symbol regex can be implemented via custom repo if needed
}
