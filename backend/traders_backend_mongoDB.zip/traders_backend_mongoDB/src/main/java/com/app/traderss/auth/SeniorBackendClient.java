package com.app.traderss.auth;

import com.app.traderss.dto.RegisterRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class SeniorBackendClient {

    private final AuthTokenService authTokenService;
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${senior.backend.enabled:false}")
    private boolean seniorBackendEnabled;

    @Value("${senior.backend.base-url:}")
    private String seniorBackendBaseUrl;

    @Value("${senior.backend.register-path:/api/auth/register}")
    private String seniorBackendRegisterPath;

    public SeniorBackendClient(AuthTokenService authTokenService) {
        this.authTokenService = authTokenService;
    }

    public SeniorRegistrationResult registerVerifiedUser(RegisterRequest req) {
        if (!seniorBackendEnabled) {
            return new SeniorRegistrationResult(false, null, null, "Senior backend disabled for local development");
        }
        if (seniorBackendBaseUrl == null || seniorBackendBaseUrl.isBlank()) {
            throw new IllegalStateException("senior.backend.base-url is required when senior.backend.enabled=true");
        }

        return registerWithCurrentToken(req, true);
    }

    private SeniorRegistrationResult registerWithCurrentToken(RegisterRequest req, boolean retryOnUnauthorized) {
        String token = authTokenService.getOrRefreshToken();
        if (token == null || token.isBlank()) {
            throw new IllegalStateException("Senior backend admin token is unavailable");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(token);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("name", req.name());
        body.put("phone", req.phone());
        body.put("email", req.email());
        body.put("password", req.password());
        body.put("role", req.role());
        body.put("accountType", req.accountType());
        body.put("brokerAccountType", req.brokerAccountType());
        body.put("swap", req.swap());

        try {
            ResponseEntity<Map> response = restTemplate.postForEntity(
                    URI.create(seniorBackendBaseUrl + seniorBackendRegisterPath),
                    new HttpEntity<>(body, headers),
                    Map.class
            );

            String seniorUserId = extractUserId(response.getBody()).orElse(null);
            String serverPassword = extractPassword(response.getBody()).orElse(null);
            return new SeniorRegistrationResult(true, seniorUserId, serverPassword, "Registered on senior backend");
        } catch (HttpStatusCodeException e) {
            if (e.getStatusCode().value() == 401 && retryOnUnauthorized) {
                authTokenService.refreshToken();
                return registerWithCurrentToken(req, false);
            }
            throw e;
        }
    }

    private Optional<String> extractUserId(Map<?, ?> body) {
        if (body == null) return Optional.empty();

        Object directId = firstNonNull(body.get("id"), body.get("_id"), body.get("userId"));
        if (directId != null) return Optional.of(String.valueOf(directId));

        Object user = body.get("user");
        if (user instanceof Map<?, ?> userMap) {
            Object nestedId = firstNonNull(userMap.get("id"), userMap.get("_id"), userMap.get("userId"));
            if (nestedId != null) return Optional.of(String.valueOf(nestedId));
        }

        Object data = body.get("data");
        if (data instanceof Map<?, ?> dataMap) {
            Object nestedId = firstNonNull(dataMap.get("id"), dataMap.get("_id"), dataMap.get("userId"));
            if (nestedId != null) return Optional.of(String.valueOf(nestedId));

            Object nestedUser = dataMap.get("user");
            if (nestedUser instanceof Map<?, ?> nestedUserMap) {
                Object userId = firstNonNull(nestedUserMap.get("id"), nestedUserMap.get("_id"), nestedUserMap.get("userId"));
                if (userId != null) return Optional.of(String.valueOf(userId));
            }
        }

        return Optional.empty();
    }

    private Optional<String> extractPassword(Map<?, ?> body) {
        if (body == null) return Optional.empty();

        Object directPassword = firstNonNull(
                body.get("password"),
                body.get("rawPassword"),
                body.get("loginPassword"),
                body.get("accountPassword")
        );
        if (directPassword != null) return Optional.of(String.valueOf(directPassword));

        Object user = body.get("user");
        if (user instanceof Map<?, ?> userMap) {
            Object nestedPassword = firstNonNull(
                    userMap.get("password"),
                    userMap.get("rawPassword"),
                    userMap.get("loginPassword"),
                    userMap.get("accountPassword")
            );
            if (nestedPassword != null) return Optional.of(String.valueOf(nestedPassword));
        }

        Object data = body.get("data");
        if (data instanceof Map<?, ?> dataMap) {
            Object nestedPassword = firstNonNull(
                    dataMap.get("password"),
                    dataMap.get("rawPassword"),
                    dataMap.get("loginPassword"),
                    dataMap.get("accountPassword")
            );
            if (nestedPassword != null) return Optional.of(String.valueOf(nestedPassword));

            Object nestedUser = dataMap.get("user");
            if (nestedUser instanceof Map<?, ?> nestedUserMap) {
                Object userPassword = firstNonNull(
                        nestedUserMap.get("password"),
                        nestedUserMap.get("rawPassword"),
                        nestedUserMap.get("loginPassword"),
                        nestedUserMap.get("accountPassword")
                );
                if (userPassword != null) return Optional.of(String.valueOf(userPassword));
            }
        }

        return Optional.empty();
    }

    private Object firstNonNull(Object... values) {
        for (Object value : values) {
            if (value != null) return value;
        }
        return null;
    }

    public record SeniorRegistrationResult(
            boolean calledSeniorBackend,
            String seniorUserId,
            String serverPassword,
            String message
    ) {}
}
