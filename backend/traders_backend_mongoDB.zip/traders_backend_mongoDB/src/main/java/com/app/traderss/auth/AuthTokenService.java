package com.app.traderss.auth;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthTokenService {

    private volatile String token;

    @Value("${senior.backend.enabled:false}")
    private boolean seniorBackendEnabled;

    @Value("${senior.backend.base-url:}")
    private String seniorBackendBaseUrl;

    @Value("${senior.backend.login-path:/api/auth/login}")
    private String seniorBackendLoginPath;

    @Value("${senior.backend.admin-email:${auth.system.email:}}")
    private String email;

    @Value("${senior.backend.admin-password:${auth.system.password:}}")
    private String password;

    public String getToken() {
        return token;
    }

    public String getOrRefreshToken() {
        if (token == null || token.isBlank()) {
            refreshToken();
        }
        return token;
    }

    @PostConstruct
    public void init() {
        if (!seniorBackendEnabled) {
            return;
        }

        Thread refreshThread = new Thread(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            refreshToken();
        });
        refreshThread.setDaemon(true);
        refreshThread.start();
    }

    @Scheduled(fixedDelayString = "${senior.backend.token-refresh-ms:3600000}")
    public void scheduledRefresh() {
        if (seniorBackendEnabled) {
            refreshToken();
        }
    }

    public synchronized void refreshToken() {
        if (!seniorBackendEnabled) {
            return;
        }
        if (seniorBackendBaseUrl == null || seniorBackendBaseUrl.isBlank()) {
            throw new IllegalStateException("senior.backend.base-url is required when senior.backend.enabled=true");
        }

        try {
            RestTemplate restTemplate = new RestTemplate();

            Map<String, String> body = new HashMap<>();
            body.put("email", email);
            body.put("password", password);

            ResponseEntity<Map> response = restTemplate.postForEntity(
                    URI.create(seniorBackendBaseUrl + seniorBackendLoginPath),
                    body,
                    Map.class
            );

            Optional<String> foundToken = extractToken(response.getBody());
            if (foundToken.isPresent()) {
                token = foundToken.get();
                System.out.println("Senior backend admin token fetched");
            } else {
                throw new IllegalStateException("Token not found in senior backend login response");
            }
        } catch (Exception e) {
            System.out.println("Senior backend token fetch failed");
            e.printStackTrace();
            throw new IllegalStateException("Senior backend token fetch failed", e);
        }
    }

    private Optional<String> extractToken(Map<?, ?> body) {
        if (body == null) return Optional.empty();

        Object tokenValue = firstNonNull(body.get("token"), body.get("accessToken"), body.get("jwt"));
        if (tokenValue instanceof String s && !s.isBlank()) {
            return Optional.of(s);
        }

        Object data = body.get("data");
        if (data instanceof Map<?, ?> dataMap) {
            Object nestedToken = firstNonNull(dataMap.get("token"), dataMap.get("accessToken"), dataMap.get("jwt"));
            if (nestedToken instanceof String s && !s.isBlank()) {
                return Optional.of(s);
            }
        }

        return Optional.empty();
    }

    private Object firstNonNull(Object... values) {
        for (Object value : values) {
            if (value != null) return value;
        }
        return null;
    }
}
