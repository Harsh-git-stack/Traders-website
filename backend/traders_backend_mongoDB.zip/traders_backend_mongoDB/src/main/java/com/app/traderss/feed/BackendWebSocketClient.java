package com.app.traderss.feed;

import com.app.traderss.trades.BackendTickRouter;
import com.app.traderss.trades.OpenTradeRepository;
import com.app.traderss.trades.OrderStatus;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.handler.AbstractWebSocketHandler;
import com.app.traderss.auth.AuthTokenService;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * WebSocket client that subscribes to feeds and aggregates ticks per-symbol.
 * It coalesces the latest tick per symbol and forwards them at a fixed interval
 * to the backend tick router.
 */
@Service
public class BackendWebSocketClient {

    private final BackendTickRouter tickRouter;
    private final OpenTradeRepository openRepo;
    private final ObjectMapper mapper = new ObjectMapper();
    private final AuthTokenService authTokenService;

    private final ScheduledExecutorService reconnectExecutor = Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService processingExecutor = Executors.newCachedThreadPool();
    private final ScheduledExecutorService tickFlushExecutor = Executors.newSingleThreadScheduledExecutor();
    private final ConcurrentHashMap<String, AtomicReference<SimpleTick>> latestTick = new ConcurrentHashMap<>();
    private final long flushIntervalMs = 200L;

    private volatile WebSocketSession cryptoSession;
    private volatile WebSocketSession forexSession;

    @Value("${backend.ws.cryptoUrl}")
    private String cryptoUrl;

    @Value("${backend.ws.forexUrl}")
    private String forexUrl;



    private final long initialDelayMs = 1000;
    private final long maxDelayMs = 30_000;
    private long cryptoReconnectDelay = initialDelayMs;
    private long forexReconnectDelay = initialDelayMs;

    public BackendWebSocketClient(
            BackendTickRouter tickRouter,
            OpenTradeRepository openRepo,
            AuthTokenService authTokenService
    ) {
        this.tickRouter = tickRouter;
        this.openRepo = openRepo;
        this.authTokenService = authTokenService;
    }

    @PostConstruct
    public void start() {
        connectWhenTokenReady();

        tickFlushExecutor.scheduleAtFixedRate(() -> {
            try {
                for (Map.Entry<String, AtomicReference<SimpleTick>> entry : latestTick.entrySet()) {
                    SimpleTick tick = entry.getValue().getAndSet(null);
                    if (tick != null) {
                        try {
                            tickRouter.routeTick(entry.getKey(), tick.bid, tick.ask);
                        } catch (Exception ex) {
                            System.err.println("Error routing tick for " + entry.getKey() + ": " + ex.getMessage());
                        }
                    }
                }
            } catch (Exception ex) {
                System.err.println("tickFlushExecutor error: " + ex.getMessage());
            }
        }, flushIntervalMs, flushIntervalMs, TimeUnit.MILLISECONDS);
    }

    private void connectWhenTokenReady() {
        String token = authTokenService.getToken();
        if (token == null || token.isBlank()) {
            System.out.println("System token not ready yet, retrying WebSocket feed connection...");
            reconnectExecutor.schedule(this::connectWhenTokenReady, 1, TimeUnit.SECONDS);
            return;
        }

        connectCrypto();
        connectForex();
    }

    @PreDestroy
    public void stop() {
        try {
            if (cryptoSession != null && cryptoSession.isOpen()) {
                cryptoSession.close();
            }
            if (forexSession != null && forexSession.isOpen()) {
                forexSession.close();
            }
        } catch (Exception ignored) {
        }
        reconnectExecutor.shutdownNow();
        processingExecutor.shutdownNow();
        tickFlushExecutor.shutdownNow();
    }

    public synchronized void subscribeSymbol(String symbol) {
        try {
            if (forexSession != null && forexSession.isOpen()) {
                forexSession.sendMessage(new TextMessage("{\"action\":\"subscribe\",\"params\":\"C." + symbol + "\"}"));
                System.out.println("SUBSCRIBED FOREX (runtime): " + symbol);
            }
            if (cryptoSession != null && cryptoSession.isOpen()) {
                cryptoSession.sendMessage(new TextMessage("{\"action\":\"subscribe\",\"params\":\"" + symbol + "\"}"));
                System.out.println("SUBSCRIBED CRYPTO (runtime): " + symbol);
            }
        } catch (Exception e) {
            System.err.println("subscribeSymbol failed for " + symbol + ": " + e.getMessage());
        }
    }

    private void connectCrypto() {
        if (cryptoSession != null && cryptoSession.isOpen()) {
            return;
        }
        try {
            connect(cryptoUrl, true);
            cryptoReconnectDelay = initialDelayMs;
        } catch (Exception ex) {
            scheduleCryptoReconnect();
        }
    }

    private void connectForex() {
        if (forexSession != null && forexSession.isOpen()) {
            return;
        }
        try {
            connect(forexUrl, false);
            forexReconnectDelay = initialDelayMs;
        } catch (Exception ex) {
            scheduleForexReconnect();
        }
    }

    private void scheduleCryptoReconnect() {
        reconnectExecutor.schedule(this::connectCrypto, cryptoReconnectDelay, TimeUnit.MILLISECONDS);
        cryptoReconnectDelay = Math.min(maxDelayMs, cryptoReconnectDelay * 2);
    }

    private void scheduleForexReconnect() {
        reconnectExecutor.schedule(this::connectForex, forexReconnectDelay, TimeUnit.MILLISECONDS);
        forexReconnectDelay = Math.min(maxDelayMs, forexReconnectDelay * 2);
    }

    private void connect(String url, boolean isCrypto) {
        WebSocketClient client = new StandardWebSocketClient();
        String resolvedUrl = withAuthToken(url);

        System.out.println("TRYING TO CONNECT: " + sanitizeUrl(resolvedUrl));

        client.execute(new AbstractWebSocketHandler() {
            @Override
            public void afterConnectionEstablished(WebSocketSession session) throws Exception {
                if (isCrypto) {
                    cryptoSession = session;
                } else {
                    forexSession = session;
                }

                System.out.println("WS CONNECTED SUCCESS: " + sanitizeUrl(resolvedUrl));

                Set<String> toSubscribe = new HashSet<>();
                openRepo.findByStatus(OrderStatus.OPEN).forEach(trade -> toSubscribe.add(trade.getSymbol()));
                openRepo.findByStatus(OrderStatus.PENDING).forEach(trade -> toSubscribe.add(trade.getSymbol()));
                System.out.println("SUBSCRIBING SYMBOLS: " + toSubscribe);

                for (String symbol : toSubscribe) {
                    if (isCrypto) {
                        System.out.println("SENDING SUBSCRIBE: " + symbol + " to " + sanitizeUrl(resolvedUrl));
                        session.sendMessage(new TextMessage("{\"action\":\"subscribe\",\"params\":\"" + symbol + "\"}"));
                        System.out.println("SUBSCRIBED CRYPTO: " + symbol);
                    } else {
                        System.out.println("SENDING SUBSCRIBE: " + symbol + " to " + sanitizeUrl(resolvedUrl));
                        session.sendMessage(new TextMessage("{\"action\":\"subscribe\",\"params\":\"C." + symbol + "\"}"));
                        System.out.println("SUBSCRIBED FOREX: " + symbol);
                    }
                }
            }

            @Override
            protected void handleTextMessage(WebSocketSession session, TextMessage message) {
                // System.out.println("RAW WS MESSAGE: " + message.getPayload());
                processingExecutor.submit(() -> handlePayload(message.getPayload()));
            }

            @Override
            public void handleTransportError(WebSocketSession session, Throwable exception) {
                System.err.println("WS transport error: " + exception.getMessage());
            }

            @Override
            public void afterConnectionClosed(WebSocketSession session, org.springframework.web.socket.CloseStatus status) {
                System.out.println("WS closed: " + sanitizeUrl(resolvedUrl) + " code=" + status.getCode());
                if (isCrypto) {
                    cryptoSession = null;
                    scheduleCryptoReconnect();
                } else {
                    forexSession = null;
                    scheduleForexReconnect();
                }
            }
        }, resolvedUrl);
    }

    private void handlePayload(String raw) {
        try {
            if (raw == null || raw.isBlank()) {
                return;
            }

            if (raw.trim().startsWith("[")) {
                JsonNode arr = mapper.readTree(raw);
                if (arr.isArray()) {
                    for (JsonNode node : arr) {
                        parseAndForward(node);
                    }
                }
                return;
            }

            JsonNode node = mapper.readTree(raw);
            parseAndForward(node);
        } catch (Exception ex) {
            System.err.println("WS parse error: " + ex.getMessage() + " raw=" + raw);
        }
    }

    private void parseAndForward(JsonNode msg) {
        try {
            if (msg == null) {
                return;
            }

            if (msg.has("ev") && "status".equals(msg.get("ev").asText())) {
                if (msg.has("status") && "auth_success".equals(msg.get("status").asText())) {
                    System.out.println("WS auth success");
                }
                return;
            }

            String ev = msg.has("ev") ? msg.get("ev").asText() : null;
            if (!("XQ".equals(ev) || "Q".equals(ev) || "C".equals(ev))) {
                return;
            }

            String pair = msg.has("pair") ? msg.get("pair").asText() : (msg.has("p") ? msg.get("p").asText() : null);
            if (pair == null) {
                return;
            }

            String symbol = normalizeSymbol(pair);
            double bid = getNumericField(msg, "bp", "b");
            double ask = getNumericField(msg, "ap", "a");

            if (!Double.isFinite(bid) || !Double.isFinite(ask) || bid <= 0 || ask <= 0) {
                return;
            }

            long ts = msg.has("t") ? msg.get("t").asLong() : System.currentTimeMillis();
            emitDelayed(symbol, bid, ask, ts);
        } catch (Exception e) {
            System.err.println("parseAndForward error: " + e.getMessage());
        }
    }

    private double getNumericField(JsonNode node, String primary, String alt) {
        try {
            if (node.has(primary) && node.get(primary).isNumber()) {
                return node.get(primary).asDouble();
            }
            if (node.has(alt) && node.get(alt).isNumber()) {
                return node.get(alt).asDouble();
            }
            if (node.has(primary) && node.get(primary).isTextual()) {
                return Double.parseDouble(node.get(primary).asText());
            }
            if (node.has(alt) && node.get(alt).isTextual()) {
                return Double.parseDouble(node.get(alt).asText());
            }
        } catch (Exception ignored) {
        }
        return Double.NaN;
    }

    private String normalizeSymbol(String rawPair) {
        if (rawPair == null) {
            return null;
        }
        return rawPair
                .replaceFirst("^.+?:", "")
                .replace("-", "")
                .replace("/", "")
                .toUpperCase();
    }

    private void emitDelayed(String symbol, double bid, double ask, long ts) {
        if (symbol == null) {
            return;
        }
        // System.out.println("BACKEND TICK: " + symbol + " bid=" + bid + " ask=" + ask);
        latestTick.computeIfAbsent(symbol, key -> new AtomicReference<>())
                .set(new SimpleTick(bid, ask, ts));
    }

    private String withAuthToken(String url) {
        String token = authTokenService.getToken();

        if (url == null || url.isBlank() || token == null || token.isBlank()) {
            return url;
        }

        return url.contains("?") ? url + "&token=" + token : url + "?token=" + token;
    }

    private String sanitizeUrl(String url) {
        String token = authTokenService.getToken();

        if (url == null || token == null || token.isBlank()) {
            return url;
        }

        return url.replace(token, "***");
    }


    private static class SimpleTick {
        final double bid;
        final double ask;
        final long ts;

        SimpleTick(double bid, double ask, long ts) {
            this.bid = bid;
            this.ask = ask;
            this.ts = ts;
        }
    }
}
