package com.app.traderss.auth;

import com.app.traderss.dto.LoginRequest;
import com.app.traderss.dto.LoginResponse;
import com.app.traderss.dto.ForgotPasswordRequest;
import com.app.traderss.dto.RegisterRequest;
import com.app.traderss.dto.ResetPasswordRequest;
import com.app.traderss.dto.VerifyRegistrationRequest;
import com.app.traderss.jwt.JwtUtil;
import com.app.traderss.trades.UserBalance;
import com.app.traderss.trades.UserBalanceRepository;
import com.app.traderss.user.AccountType;
import com.app.traderss.user.User;
import com.app.traderss.user.UserRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpStatusCodeException;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api/auth")
@Validated
public class AuthController {

    private final UserRepository userRepo;
    private final BCryptPasswordEncoder encoder;
    private final JwtUtil jwtUtil;
    private final RedisTemplate<String, String> redisTemplate;
    private final UserBalanceRepository userBalanceRepo;
    private final PendingRegistrationRepository pendingRegistrationRepo;
    private final PasswordResetOtpRepository passwordResetOtpRepo;
    private final EmailOtpService emailOtpService;
    private final SeniorBackendClient seniorBackendClient;

    @Value("${app.otp.expiry-minutes:10}")
    private long otpExpiryMinutes;

    private static final Pattern PASSWORD_PATTERN = Pattern
            .compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{12,}$");

    public AuthController(
            UserRepository userRepo,
            BCryptPasswordEncoder encoder,
            UserBalanceRepository userBalanceRepo,
            JwtUtil jwtUtil,
            RedisTemplate<String, String> redisTemplate,
            PendingRegistrationRepository pendingRegistrationRepo,
            PasswordResetOtpRepository passwordResetOtpRepo,
            EmailOtpService emailOtpService,
            SeniorBackendClient seniorBackendClient) {
        this.userRepo = userRepo;
        this.encoder = encoder;
        this.jwtUtil = jwtUtil;
        this.redisTemplate = redisTemplate;
        this.userBalanceRepo = userBalanceRepo;
        this.pendingRegistrationRepo = pendingRegistrationRepo;
        this.passwordResetOtpRepo = passwordResetOtpRepo;
        this.emailOtpService = emailOtpService;
        this.seniorBackendClient = seniorBackendClient;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest req) {
        ValidationResult validation = validateRegistration(req);
        if (!validation.valid()) {
            return ResponseEntity.badRequest().body(validation.message());
        }

        String normalizedEmail = normalizeEmail(req.email());
        if (userRepo.existsByEmail(normalizedEmail)) {
            return ResponseEntity.badRequest().body("Email already exists");
        }

        String otp = emailOtpService.generateOtp();
        PendingRegistration pending = pendingRegistrationRepo.findByEmail(normalizedEmail)
                .orElseGet(PendingRegistration::new);

        pending.setEmail(normalizedEmail);
        pending.setName(req.name());
        pending.setPhone(req.phone());
        pending.setPassword(req.password());
        pending.setRole(normalizeRole(req.role()));
        pending.setAccountType(validation.accountType().name());
        pending.setBrokerAccountType(resolveBrokerAccountType(req, validation.accountType()));
        pending.setSwap(req.swap());
        pending.setOtpHash(encoder.encode(otp));
        pending.setCreatedAt(Instant.now());
        pending.setExpiresAt(Instant.now().plus(Duration.ofMinutes(otpExpiryMinutes)));
        pendingRegistrationRepo.save(pending);

        emailOtpService.sendSignupOtp(normalizedEmail, req.name(), otp);

        String message = emailOtpService.isMailEnabled()
                ? "OTP sent to email. Verify it to finish registration."
                : "OTP generated in local dev mode. Check the backend console/log, then verify it.";

        return ResponseEntity.ok(Map.of(
                "message", message,
                "email", normalizedEmail,
                "deliveryMode", emailOtpService.isMailEnabled() ? "email" : "console",
                "expiresInMinutes", otpExpiryMinutes
        ));
    }

    @PostMapping("/verify-registration")
    public ResponseEntity<?> verifyRegistration(@Valid @RequestBody VerifyRegistrationRequest req) {
        String normalizedEmail = normalizeEmail(req.email());
        PendingRegistration pending = pendingRegistrationRepo.findByEmail(normalizedEmail).orElse(null);

        if (pending == null) {
            return ResponseEntity.badRequest().body("No pending registration found for this email");
        }
        if (pending.getExpiresAt() == null || pending.getExpiresAt().isBefore(Instant.now())) {
            pendingRegistrationRepo.delete(pending);
            return ResponseEntity.badRequest().body("OTP expired. Please sign up again.");
        }
        if (!encoder.matches(req.otp(), pending.getOtpHash())) {
            return ResponseEntity.badRequest().body("Invalid OTP");
        }
        if (userRepo.existsByEmail(normalizedEmail)) {
            pendingRegistrationRepo.delete(pending);
            return ResponseEntity.badRequest().body("Email already exists");
        }

        RegisterRequest registerRequest = pending.toRegisterRequest();
        SeniorBackendClient.SeniorRegistrationResult seniorResult;
        try {
            seniorResult = seniorBackendClient.registerVerifiedUser(registerRequest);
        } catch (HttpStatusCodeException e) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Map.of(
                    "message", "Senior backend registration failed",
                    "status", e.getStatusCode().value(),
                    "response", e.getResponseBodyAsString()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Map.of(
                    "message", "Senior backend registration failed",
                    "error", e.getMessage() == null ? "Unknown error" : e.getMessage()
            ));
        }

        AccountType accountType = AccountType.fromString(registerRequest.accountType());
        if (accountType == null) {
            accountType = AccountType.LIVE;
        }

        User saved = createLocalUser(registerRequest, accountType, seniorResult);
        pendingRegistrationRepo.delete(pending);
        saved.setPasswordHash(null);

        String displayUserId = seniorResult.seniorUserId() != null ? seniorResult.seniorUserId() : saved.getId();
        String displayPassword = seniorResult.serverPassword() != null ? seniorResult.serverPassword() : registerRequest.password();

        return ResponseEntity.ok(Map.of(
                "message", "Email verified and account created.",
                "user", saved,
                "serverUserId", displayUserId,
                "serverPassword", displayPassword,
                "seniorBackendCalled", seniorResult.calledSeniorBackend(),
                "seniorBackendMessage", seniorResult.message()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest req) {
        User user = userRepo.findByEmail(normalizeEmail(req.email())).orElse(null);

        if (user == null || !encoder.matches(req.password(), user.getPasswordHash())) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user.getId(), user.getRole());
        user.setPasswordHash(null);

        return ResponseEntity.ok(new LoginResponse(token, user));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@Valid @RequestBody ForgotPasswordRequest req) {
        String normalizedEmail = normalizeEmail(req.email());
        User user = userRepo.findByEmail(normalizedEmail).orElse(null);

        if (user == null) {
            return ResponseEntity.badRequest().body("No account found for this email");
        }

        String otp = emailOtpService.generateOtp();
        PasswordResetOtp resetOtp = passwordResetOtpRepo.findByEmail(normalizedEmail)
                .orElseGet(PasswordResetOtp::new);
        resetOtp.setEmail(normalizedEmail);
        resetOtp.setOtpHash(encoder.encode(otp));
        resetOtp.setCreatedAt(Instant.now());
        resetOtp.setExpiresAt(Instant.now().plus(Duration.ofMinutes(otpExpiryMinutes)));
        passwordResetOtpRepo.save(resetOtp);

        emailOtpService.sendPasswordResetOtp(normalizedEmail, otp);

        return ResponseEntity.ok(Map.of(
                "message", "Password reset OTP sent to email.",
                "email", normalizedEmail,
                "expiresInMinutes", otpExpiryMinutes
        ));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@Valid @RequestBody ResetPasswordRequest req) {
        String normalizedEmail = normalizeEmail(req.email());
        User user = userRepo.findByEmail(normalizedEmail).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body("No account found for this email");
        }

        PasswordResetOtp resetOtp = passwordResetOtpRepo.findByEmail(normalizedEmail).orElse(null);
        if (resetOtp == null) {
            return ResponseEntity.badRequest().body("No password reset request found for this email");
        }
        if (resetOtp.getExpiresAt() == null || resetOtp.getExpiresAt().isBefore(Instant.now())) {
            passwordResetOtpRepo.delete(resetOtp);
            return ResponseEntity.badRequest().body("OTP expired. Please request a new OTP.");
        }
        if (!encoder.matches(req.otp(), resetOtp.getOtpHash())) {
            return ResponseEntity.badRequest().body("Invalid OTP");
        }
        if (!PASSWORD_PATTERN.matcher(req.newPassword()).matches()) {
            return ResponseEntity.badRequest().body(
                    "Password must be at least 12 characters with uppercase, lowercase, number, and special char");
        }

        user.setPasswordHash(encoder.encode(req.newPassword()));
        userRepo.save(user);
        passwordResetOtpRepo.delete(resetOtp);

        return ResponseEntity.ok(Map.of("message", "Password reset successful. You can now log in."));
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody RefreshRequest refreshReq) {
        String oldToken = refreshReq.getOldToken();
        Claims claims = null;
        try {
            claims = jwtUtil.parseClaims(oldToken);
        } catch (ExpiredJwtException e) {
            claims = e.getClaims();
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Invalid token");
        }

        if (claims == null || redisTemplate.opsForValue().get("blacklist:" + oldToken) != null) {
            return ResponseEntity.status(401).body("Token revoked");
        }

        String newToken = jwtUtil.generateToken(claims.getSubject(), claims.get("role", String.class));

        long expiryMs = claims.getExpiration().getTime() - System.currentTimeMillis();
        long expirySeconds = Math.max(60, expiryMs / 1000);
        redisTemplate.opsForValue().set("blacklist:" + oldToken, "revoked", Duration.ofSeconds(expirySeconds));

        return ResponseEntity.ok(new LoginResponse(newToken, null));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader("Authorization") String authHeader) {
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            Claims claims = null;
            try {
                claims = jwtUtil.parseClaims(token);
            } catch (ExpiredJwtException e) {
                claims = e.getClaims();
            } catch (Exception e) {
                return ResponseEntity.status(401).body("Invalid token");
            }

            if (claims != null) {
                long expiryMs = claims.getExpiration().getTime() - System.currentTimeMillis();
                long expirySeconds = Math.max(60, expiryMs / 1000);
                redisTemplate.opsForValue().set("blacklist:" + token, "revoked", Duration.ofSeconds(expirySeconds));
            }
            return ResponseEntity.ok("Logged out");
        }
        return ResponseEntity.badRequest().body("Missing token");
    }

    private User createLocalUser(
            RegisterRequest req,
            AccountType accountType,
            SeniorBackendClient.SeniorRegistrationResult seniorResult) {
        User user = new User();
        user.setName(req.name());
        user.setEmail(normalizeEmail(req.email()));
        user.setPhone(req.phone());
        user.setRole(normalizeRole(req.role()));
        user.setPasswordHash(encoder.encode(req.password()));
        user.setAccountNumber(10001 + userRepo.count());
        user.setAccountType(accountType);
        user.setBrokerAccountType(resolveBrokerAccountType(req, accountType));
        user.setSwapValue(req.swap());
        user.setSeniorUserId(seniorResult.seniorUserId());
        if (seniorResult.calledSeniorBackend()) {
            user.setSeniorRegisteredAt(Instant.now());
        }

        User saved = userRepo.save(user);

        UserBalance ub = new UserBalance();
        ub.setUserId(saved.getId());
        if (accountType == AccountType.DEMO) {
            ub.setBalance(100000.0);
            ub.setCredit(0.0);
        } else {
            ub.setBalance(0.0);
            ub.setCredit(0.0);
        }
        userBalanceRepo.save(ub);

        return saved;
    }

    private ValidationResult validateRegistration(RegisterRequest req) {
        if (!PASSWORD_PATTERN.matcher(req.password()).matches()) {
            return ValidationResult.invalid(
                    "Password must be at least 12 characters with uppercase, lowercase, number, and special char");
        }

        AccountType accountType = AccountType.fromString(req.accountType());
        if (accountType == null && req.accountType() != null && !req.accountType().isBlank()) {
            accountType = AccountType.LIVE;
        }
        if (accountType == null) {
            return ValidationResult.invalid("Invalid accountType. Allowed values: DEMO, LIVE");
        }

        return ValidationResult.valid(accountType);
    }

    private String normalizeEmail(String email) {
        return email == null ? null : email.trim().toLowerCase();
    }

    private String normalizeRole(String role) {
        return role == null || role.isBlank() ? "USER" : role.trim().toUpperCase();
    }

    private String resolveBrokerAccountType(RegisterRequest req, AccountType accountType) {
        if (req.brokerAccountType() != null && !req.brokerAccountType().isBlank()) {
            return req.brokerAccountType().trim();
        }
        if (req.accountType() != null && !req.accountType().equalsIgnoreCase(accountType.name())) {
            return req.accountType().trim();
        }
        return accountType.name();
    }

    private record ValidationResult(boolean valid, String message, AccountType accountType) {
        static ValidationResult valid(AccountType accountType) {
            return new ValidationResult(true, null, accountType);
        }

        static ValidationResult invalid(String message) {
            return new ValidationResult(false, message, null);
        }
    }
}
