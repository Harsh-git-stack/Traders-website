package com.app.traderss.trades;

import org.springframework.stereotype.Component;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertEvent;

@Component
public class OpenTradeMongoListener extends AbstractMongoEventListener<OpenTrade> {

    private final TradeService tradeService;

    public OpenTradeMongoListener(TradeService tradeService) {
        this.tradeService = tradeService;
    }

    @Override
    public void onBeforeConvert(BeforeConvertEvent<OpenTrade> event) {
        OpenTrade t = event.getSource();
        if (t == null) return;
        // compute / attach pip info before saving to MongoDB
        tradeService.attachPipInfo(t);
    }
}
