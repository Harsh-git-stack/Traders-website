package com.app.traderss.dto;

public class ChangePasswordRequest {
    private String userId;
    private String newPassword;

    public ChangePasswordRequest() {}

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getNewPassword() { return newPassword; }
    public void setNewPassword(String newPassword) { this.newPassword = newPassword; }
}