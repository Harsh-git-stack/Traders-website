package com.app.traderss.service;


import com.app.traderss.trades.OpenTrade;
import com.app.traderss.trades.OpenTradeRepository;
import com.app.traderss.trades.UserBalance;
import com.app.traderss.trades.UserBalanceRepository;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class AccountService {

    private final OpenTradeRepository openRepo;
    private final UserBalanceRepository balanceRepo;

    // Example margin per lot (can be per symbol later)
    private static final double MARGIN_PER_LOT_FOREX = 1000;

    public AccountService(OpenTradeRepository openRepo, UserBalanceRepository balanceRepo) {
        this.openRepo = openRepo;
        this.balanceRepo = balanceRepo;
    }

public AccountSnapshot calculate(String userId) {

    UserBalance bal = balanceRepo.findByUserId(userId)
        .orElseGet(() -> {
            // 👇 CREATE BALANCE ON FIRST ACCESS
            UserBalance nb = new UserBalance(userId, 0, 0); // demo balance
            return balanceRepo.save(nb);
        });

    double balance = bal.getBalance();
    double credit = bal.getCredit();

    List<OpenTrade> opens = openRepo.findByUserId(userId);

    double margin = opens.stream()
        .mapToDouble(t -> t.getVolume() * MARGIN_PER_LOT_FOREX)
        .sum();
    double totalSwap = opens.stream().mapToDouble(OpenTrade::getAccumulatedSwap).sum();
    double totalCommission = opens.stream().mapToDouble(OpenTrade::getAccumulatedCommission).sum();
    double floating = opens.stream().mapToDouble(OpenTrade::getProfit).sum() + totalSwap + totalCommission;
    double equity = balance + floating;
    double freeMargin = equity - margin;
    double marginLevel = margin > 0 ? (equity / margin) * 100 : 0;
    return new AccountSnapshot(
        balance,
        equity,
        margin,
        freeMargin,
        marginLevel,
        credit
    );
}
    public record AccountSnapshot(
            double balance,
            double equity,
            double margin,
            double freeMargin,
            double marginLevel,
            double credit
    ) {}
}

