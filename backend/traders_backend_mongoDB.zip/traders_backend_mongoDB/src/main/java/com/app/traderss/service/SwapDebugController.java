package com.app.traderss.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SwapDebugController {

    private final SwapAccrualService swapAccrualService;

    public SwapDebugController(SwapAccrualService swapAccrualService) {
        this.swapAccrualService = swapAccrualService;
    }

    @PostMapping("/accrue-swaps-now")
    public ResponseEntity<String> triggerAccrueNow() {
        swapAccrualService.accrueAll();
        return ResponseEntity.ok("Swap accrual triggered");
    }
}
