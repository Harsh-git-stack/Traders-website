package com.app.traderss.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record RegisterRequest(
        @NotBlank String name,
        String phone,
        @Email @NotBlank String email,
        @NotBlank String password,
        @NotBlank String role,
        String accountType,// "DEMO" or "LIVE" (optional, defaults to LIVE)
        String brokerAccountType,
        Boolean swap
) {}
