package com.app.traderss.symbols;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.time.Instant;
import java.util.*;

@Service
public class MassiveSymbolSyncService {

    private final MongoTemplate mongoTemplate;
    private final ObjectMapper objectMapper;
    private final WebClient webClient;

    private final String baseUrl;
    private final String apiKey;
    private final int pageLimit;
    private final String fxMarket;
    private final String cryptoMarket;

    public MassiveSymbolSyncService(
            MongoTemplate mongoTemplate,
            ObjectMapper objectMapper,
            @Value("${massive.base-url}") String baseUrl,
            @Value("${massive.api-key}") String apiKey,
            @Value("${massive.page-limit:100}") int pageLimit,
            @Value("${massive.fx-market:fx}") String fxMarket,
            @Value("${massive.crypto-market:crypto}") String cryptoMarket) {

        this.mongoTemplate = mongoTemplate;
        this.objectMapper = objectMapper;
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.apiKey = apiKey;
        this.pageLimit = pageLimit;
        this.fxMarket = fxMarket;
        this.cryptoMarket = cryptoMarket;

        this.webClient = WebClient.builder()
                .baseUrl(this.baseUrl)
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + this.apiKey)
                .build();
    }

    // ============================
    // INFERENCE METHODS
    // ============================

    private double inferMarginRate(String symbol, String type) {

        String s = symbol.toUpperCase();

        // ===== CRYPTO =====
        if ("CRYPTO".equalsIgnoreCase(type)) {
            return 0.10;
        }

        // ===== INDICES =====
        if (s.contains("NAS") || s.contains("SPX") || s.contains("US30") ||
                s.contains("DAX") || s.contains("FTSE") || s.contains("NIKKEI")) {
            return 0.03;
        }

        // ===== OIL / ENERGY =====
        if (s.contains("OIL") || s.contains("BRENT") || s.contains("WTI")) {
            return 0.05;
        }

        // ===== GOLD / METALS =====
        if (s.startsWith("XAU") || s.startsWith("XAG")) {
            return 0.015;
        }

        // ===== FOREX MAJORS =====
        if (isForexMajor(s)) {
            return 0.01;
        }

        // ===== FOREX MINORS =====
        if (isForexMinor(s)) {
            return 0.02;
        }

        // default fallback
        return 0.02;
    }

    private boolean isForexMajor(String symbol) {
        String s = symbol.toUpperCase();

        return s.contains("EURUSD") ||
                s.contains("GBPUSD") ||
                s.contains("USDJPY") ||
                s.contains("USDCHF") ||
                s.contains("AUDUSD") ||
                s.contains("USDCAD") ||
                s.contains("NZDUSD");
    }

    private boolean isForexMinor(String symbol) {
        return symbol.length() == 6; // fallback rule
    }

    private int inferDigits(String symbol) {
        if (symbol == null) return 5;
        String s = symbol.toUpperCase();

        if (s.startsWith("XAU")) return 2;      // Gold
        if (s.startsWith("XAG")) return 3;      // Silver
        if (s.contains("JPY")) return 3;        // JPY pairs

        // Major cryptocurrencies (BTC, ETH, etc.)
        if (s.startsWith("BTC") || s.startsWith("ETH") ||
                s.startsWith("BNB") || s.startsWith("SOL")) {
            return 2;
        }

        return 5; // Default for most forex and other cryptos
    }

    /**
     * tickSize = 10 ^ (-digits)   ← As per your requirement
     */
    private double calculateTickSize(int digits) {
        return Math.pow(10, -digits);
    }

    /**
     * Standard pip size (industry convention) - kept for reference
     */
    private double inferPipSize(String symbol) {
        if (symbol == null) return 0.0001;
        String s = symbol.toUpperCase();

        if (s.startsWith("XAU")) return 0.01;
        if (s.startsWith("XAG")) return 0.001;
        if (s.contains("JPY")) return 0.01;
        return 0.0001;
    }

    private double inferContractSize(String symbol, boolean isCrypto) {
        if (isCrypto) return 1.0;

        String s = symbol.toUpperCase();
        if (s.startsWith("XAU")) return 100;
        if (s.startsWith("XAG")) return 5000;

        return 100000; // Standard forex contract size
    }

    private String normalizeTicker(String raw) {
        if (raw == null) return null;
        return raw.replaceFirst("^.+?:", "")
                .replaceAll("[^A-Za-z0-9]", "")
                .toUpperCase();
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onReady() {
        new Thread(() -> syncMarket(fxMarket, "FOREX")).start();
        new Thread(() -> syncMarket(cryptoMarket, "CRYPTO")).start();
    }

    @Scheduled(cron = "${sync.tickers-cron:0 0 * * * *}")
    public void scheduledSync() {
        syncMarket(fxMarket, "FOREX");
        syncMarket(cryptoMarket, "CRYPTO");
    }

    public void syncMarket(String market, String typeLabel) {
        System.out.println("🔥 Sync START: " + market + " (" + typeLabel + ")");

        String path = String.format(
                "/v3/reference/tickers?market=%s&active=true&order=asc&limit=%d&sort=ticker&apiKey=%s",
                market, pageLimit, apiKey);

        try {
            while (path != null && !path.isBlank()) {

                String body = webClient.get().uri(path)
                        .retrieve()
                        .bodyToMono(String.class)
                        .block();

                JsonNode root = objectMapper.readTree(body);
                JsonNode results = root.get("results");

                List<SymbolSpec> list = new ArrayList<>();

                for (JsonNode it : results) {
                    String raw = it.has("ticker") ? it.get("ticker").asText() : null;
                    if (raw == null) continue;

                    String symbol = normalizeTicker(raw);
                    if (symbol == null) continue;

                    String name = it.has("name") ? it.get("name").asText() : symbol;
                    boolean active = it.has("active") && it.get("active").asBoolean();
                    SymbolSpec s = buildSpec(symbol, name, raw, typeLabel, active);
                    list.add(s);
                }

                bulkUpsert(list);

                String next = root.has("next_url") ? root.get("next_url").asText(null) : null;
                if (next == null) break;

                path = next.replaceFirst("^https?://[^/]+", "");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ============================
    // BUILD SYMBOL SPEC
    // ============================

    private SymbolSpec buildSpec(String symbol, String name, String raw, String type, boolean active) {

        boolean isForex = "FOREX".equalsIgnoreCase(type);
        boolean isCrypto = "CRYPTO".equalsIgnoreCase(type);
        double marginRate = inferMarginRate(symbol, type);

        SymbolSpec s = new SymbolSpec();

        s.setId(symbol);
        s.setName(name);
        s.setDescription(name);
        s.setType(type);
        s.setSource("massive");
        s.setSourceId(raw);
        s.setActive(active);
        s.setLastUpdated(Instant.now());
        s.setMarginRate(marginRate);
        // ===== PRICE FIELDS - MAIN LOGIC =====
        int digits = isCrypto ? 2 : inferDigits(symbol);
        double tickSize = calculateTickSize(digits);     // 10^(-digits)
        double pipSize = inferPipSize(symbol);           // Standard pip (for reference)
        double contractSize = inferContractSize(symbol, isCrypto);

        s.setDigits(digits);
        s.setTickSize(tickSize);      // ← This is what you use in PnL
        s.setPipSize(pipSize);        // Standard pip value
        s.setContractSize(contractSize);

        // ===== GENERAL SETTINGS =====
        s.setExchange(isForex ? "XCCY" : "CRYPTO");
        s.setSector(isForex ? "Currency" : "Crypto");

        s.setSpreadType("Floating");
        s.setSpread("0");
        s.setStopLevels(0);

        s.setMarginCurrency(isForex ? symbol.substring(0, 3) : "USD");
        s.setProfitCurrency(isForex ? symbol.substring(3, 6) : "USD");

        s.setCalculation(isForex ? "Forex" : "CFD");
        s.setHedgedMargin(isForex ? 100000 : 1);

        s.setTrade("Full access");
        s.setChartMode("By bid price");
        s.setExecution("Market Execution");
        s.setGtcMode("Good till cancelled");
        s.setFillPolicy("Fill or Kill");
        s.setExpiration("All");
        s.setOrders("All");

        // ===== VOLUME =====
        s.setMinimalVolume(0.01);
        s.setMaximalVolume(500);
        s.setVolumeStep(0.01);

        // ===== SWAPS =====
        s.setSwapType("In points");
        s.setSwapLong(isForex ? -0.7 : 0);
        s.setSwapShort(isForex ? -1 : 0);

        Map<String, Integer> swaps = new LinkedHashMap<>();
        swaps.put("monday", isForex ? 1 : 0);
        swaps.put("tuesday", isForex ? 1 : 0);
        swaps.put("wednesday", isForex ? 3 : 0);
        swaps.put("thursday", isForex ? 1 : 0);
        swaps.put("friday", isForex ? 1 : 0);
        s.setSwapRates(swaps);

        // ===== SESSIONS =====
        Map<String, String> sessions = new LinkedHashMap<>();
        sessions.put("monday", "00:00-24:00");
        sessions.put("tuesday", "00:00-24:00");
        sessions.put("wednesday", "00:00-24:00");
        sessions.put("thursday", "00:00-24:00");
        sessions.put("friday", "00:00-24:00");

        s.setQuotesSessions(sessions);
        s.setTradeSessions(new LinkedHashMap<>(sessions));




        return s;
    }

    // ============================
    // BULK UPSERT (includes tickSize)
    // ============================

    private void bulkUpsert(List<SymbolSpec> list) {
        if (list.isEmpty()) return;

        BulkOperations bulk = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, SymbolSpec.class);

        for (SymbolSpec s : list) {
            Query q = Query.query(Criteria.where("_id").is(s.getId()));

            Update u = new Update()
                    .set("name", s.getName())
                    .set("description", s.getDescription())
                    .set("type", s.getType())
                    .set("active", s.isActive())
                    .set("source", s.getSource())
                    .set("sourceId", s.getSourceId())
                    .set("lastUpdated", s.getLastUpdated())

                    .set("exchange", s.getExchange())
                    .set("sector", s.getSector())
                    .set("digits", s.getDigits())
                    .set("tickSize", s.getTickSize())      // ← Important
                    .set("pipSize", s.getPipSize())
                    .set("contractSize", s.getContractSize())

                    .set("spreadType", s.getSpreadType())
                    .set("spread", s.getSpread())
                    .set("stopLevels", s.getStopLevels())

                    .set("marginCurrency", s.getMarginCurrency())
                    .set("profitCurrency", s.getProfitCurrency())
                    .set("calculation", s.getCalculation())
                    .set("hedgedMargin", s.getHedgedMargin())

                    .set("trade", s.getTrade())
                    .set("chartMode", s.getChartMode())
                    .set("execution", s.getExecution())
                    .set("gtcMode", s.getGtcMode())
                    .set("fillPolicy", s.getFillPolicy())
                    .set("expiration", s.getExpiration())
                    .set("orders", s.getOrders())

                    .set("minimalVolume", s.getMinimalVolume())
                    .set("maximalVolume", s.getMaximalVolume())
                    .set("volumeStep", s.getVolumeStep())

                    .set("swapType", s.getSwapType())
                    .set("swapLong", s.getSwapLong())
                    .set("swapShort", s.getSwapShort())
                    .set("swapRates", s.getSwapRates())

                    .set("quotesSessions", s.getQuotesSessions())
                    .set("marginRate",s.getMarginRate())
                    .set("tradeSessions", s.getTradeSessions());


            bulk.upsert(q, u);
        }

        bulk.execute();
    }
}