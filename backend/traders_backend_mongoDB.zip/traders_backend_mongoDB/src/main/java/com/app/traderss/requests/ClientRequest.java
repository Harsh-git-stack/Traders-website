package com.app.traderss.requests;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@Document(collection = "client_requests")
public class ClientRequest {

    @Id
    private String id;

    @Indexed
    private String userId;

    @Indexed
    private String category;

    private String requestType;
    private String status = "PENDING";
    private Map<String, Object> payload = new LinkedHashMap<>();

    @Indexed
    private Instant createdAt = Instant.now();

    private Instant updatedAt = Instant.now();
}
