package com.app.traderss.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.lang.reflect.Proxy;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Configuration
@ConditionalOnProperty(name = "app.redis.enabled", havingValue = "false")
public class LocalRedisFallbackConfig {

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager();
    }

    @Bean
    @Primary
    public RedisTemplate<String, Object> redisTemplate() {
        return new InMemoryRedisTemplate();
    }

    static class InMemoryRedisTemplate extends RedisTemplate<String, Object> {
        private final Map<String, Object> store = new ConcurrentHashMap<>();

        @Override
        public void afterPropertiesSet() {
            // Local mode does not use a RedisConnectionFactory.
        }

        @Override
        @SuppressWarnings("unchecked")
        public ValueOperations<String, Object> opsForValue() {
            return (ValueOperations<String, Object>) Proxy.newProxyInstance(
                    ValueOperations.class.getClassLoader(),
                    new Class<?>[]{ValueOperations.class},
                    (proxy, method, args) -> {
                        String name = method.getName();
                        if ("get".equals(name) && args != null && args.length >= 1) {
                            return store.get(String.valueOf(args[0]));
                        }
                        if ("set".equals(name) && args != null && args.length >= 2) {
                            store.put(String.valueOf(args[0]), args[1]);
                            return null;
                        }
                        if ("increment".equals(name) && args != null && args.length >= 1) {
                            String key = String.valueOf(args[0]);
                            Number by = args.length >= 2 && args[1] instanceof Number n ? n : 1;
                            double next = ((Number) store.getOrDefault(key, 0)).doubleValue() + by.doubleValue();
                            store.put(key, next);
                            return next;
                        }
                        return defaultValue(method.getReturnType());
                    });
        }

        @Override
        public Long convertAndSend(String channel, Object message) {
            return 0L;
        }

        private Object defaultValue(Class<?> type) {
            if (type == boolean.class) return false;
            if (type == int.class) return 0;
            if (type == long.class) return 0L;
            if (type == double.class) return 0.0;
            if (type == float.class) return 0f;
            if (type == Duration.class) return Duration.ZERO;
            return null;
        }
    }
}
