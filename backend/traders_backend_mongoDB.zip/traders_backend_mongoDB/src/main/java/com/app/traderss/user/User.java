package com.app.traderss.user;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import com.app.traderss.user.AccountType;

import java.time.Instant;

@Getter
@Setter
@Document(collection = "users")
public class User {

    @Id
    private String id;

    @Indexed
    private String name;
    @Indexed(unique = true)
    private String email;
    private String phone;
    private String passwordHash;

    private long accountNumber;
    // private double balance;

    private String role;

    private AccountType accountType;
    private String brokerAccountType;
    private String seniorUserId;
    private Instant seniorRegisteredAt;

    private Boolean isBlocked = false; //added boolean val for now later will switch to enum

    private Instant createdAt = Instant.now();
    private Boolean swapValue;


}
