package com.app.traderss.trades;

import com.app.traderss.dto.BalanceDepositRequest;
import com.app.traderss.dto.CreditDepositRequest;
import com.app.traderss.dto.ModifyTradeRequest;
import com.app.traderss.dto.CloseTradeRequest;
import com.app.traderss.dto.PartialCloseRequest;
import com.app.traderss.jwt.JwtUtil;
import com.app.traderss.service.AccountService;
import com.app.traderss.trades.kafka.ModifyTradeEvent;
import com.app.traderss.trades.kafka.OpenTradeEvent;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.*;
import org.bson.Document;
import com.app.traderss.dto.ChangePasswordRequest;
import com.app.traderss.feed.BackendWebSocketClient;

@RestController
@RequestMapping("/api/trades")
public class TradesController {

    private final OpenTradeRepository openRepo;
    private final ClosedTradeRepository closedRepo;
    private final UserBalanceRepository balanceRepo;
    private final JwtUtil jwtUtil;
    private final TradeService tradeService;
    private final AccountService accountService;
    private final MongoTemplate mongoTemplate;
    private final SimpMessagingTemplate messagingTemplate;
    private final TradeExecutionService execService;
    private final RedisTemplate<String, Object> redisTemplate;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final BackendWebSocketClient backendWebSocketClient;

    public TradesController(
            OpenTradeRepository openRepo,
            ClosedTradeRepository closedRepo,
            UserBalanceRepository balanceRepo,
            JwtUtil jwtUtil,
            TradeService tradeService,
            AccountService accountService,
            MongoTemplate mongoTemplate,
            SimpMessagingTemplate messagingTemplate,
            TradeExecutionService execService,
            RedisTemplate<String, Object> redisTemplate,
            KafkaTemplate<String, Object> kafkaTemplate,
            BackendWebSocketClient backendWebSocketClient) {
        this.openRepo = openRepo;
        this.closedRepo = closedRepo;
        this.balanceRepo = balanceRepo;
        this.jwtUtil = jwtUtil;
        this.tradeService = tradeService;
        this.accountService = accountService;
        this.mongoTemplate = mongoTemplate;
        this.messagingTemplate = messagingTemplate;
        this.execService = execService;
        this.redisTemplate = redisTemplate;
        this.kafkaTemplate = kafkaTemplate;
        this.backendWebSocketClient = backendWebSocketClient;
    }

    private Optional<String> getUserIdSafe(HttpServletRequest req) {
        String auth = req.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer "))
            return Optional.empty();
        try {
            return Optional.of(jwtUtil.extractUserId(auth.substring(7)));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    @GetMapping
    public ResponseEntity<?> loadTrades(HttpServletRequest req) {
        Optional<String> uidOpt = getUserIdSafe(req);
        if (uidOpt.isEmpty()) {
            return ResponseEntity.status(401)
                    .body(Map.of("retcode", 10016, "error", "Invalid token"));
        }

        String uid = uidOpt.get();

        List<OpenTrade> open = openRepo.findByUserId(uid);
        List<ClosedTrade> closed = closedRepo.findByUserId(uid);
        AccountService.AccountSnapshot balance = accountService.calculate(uid);

        String userKey = "user:" + uid;
        redisTemplate.opsForValue().set(userKey + ":openTrades", open);
        redisTemplate.opsForValue().set(userKey + ":closedTrades", closed);
        redisTemplate.opsForValue().set(userKey + ":balance", balance);
        redisTemplate.opsForValue().set(userKey + ":lastUpdateMs", System.currentTimeMillis());

        Map<String, Object> res = new HashMap<>();
        res.put("open", open);
        res.put("closed", closed);
        res.put("balance", balance);
        return ResponseEntity.ok(res);
    }

    @GetMapping("/account")
    public ResponseEntity<?> account(HttpServletRequest req) {
        Optional<String> uidOpt = getUserIdSafe(req);
        if (uidOpt.isEmpty()) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok(accountService.calculate(uidOpt.get()));
    }

    @PostMapping("/open")
    public ResponseEntity<?> openTrade(@RequestBody OpenTrade trade, HttpServletRequest req) {

        Optional<String> uidOpt = getUserIdSafe(req);
        if (uidOpt.isEmpty())
            return ResponseEntity.status(401).body(Map.of("retcode", 10016, "error", "Invalid token"));
        String uid = uidOpt.get();

        try {
            tradeService.validateUserNotBlocked(uid);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }

        trade.setUserId(uid);


        if (trade.getOrderType() != null) {
    boolean isBuy = trade.getOrderType().name().startsWith("BUY");
    trade.setType(isBuy ? "buy" : "sell");
}

        if (!validateSLTP(trade)) {
            return ResponseEntity.badRequest().body(Map.of("retcode", 10014, "error", "Invalid stops"));
        }

        trade.setStatus(trade.getOrderType() == OrderType.BUY || trade.getOrderType() == OrderType.SELL
                ? OrderStatus.OPEN
                : OrderStatus.PENDING);
        trade.setTime(Instant.now().toString());


        int count = trade.getTradeCount() != 0 ? trade.getTradeCount() : 1; //safety check to handle nulls
        double commissionRate = -3.0;
        trade.setAccumulatedCommission(trade.getVolume() * commissionRate * trade.getTradeCount());  //value multiplied by tradecount

        OpenTrade saved = openRepo.save(trade);

        // Only force tick if we have a valid open price
        Double openPrice = trade.getOpenPrice();
        if (openPrice != null && openPrice > 0) {
            execService.onTick(trade.getSymbol(), openPrice, openPrice);
        }

        if (saved.getStatus() == OrderStatus.PENDING) {
            execService.addPendingToCache(saved);
        } else if (saved.getStatus() == OrderStatus.OPEN) {
            execService.addOpenToCache(saved);
        }

        backendWebSocketClient.subscribeSymbol(saved.getSymbol());

        long nowMs = System.currentTimeMillis();
        String userKey = "user:" + uid;
        redisTemplate.opsForValue().set(userKey + ":lastUpdateMs", nowMs);
        List<OpenTrade> openTrades = openRepo.findByUserId(uid);
        redisTemplate.opsForValue().set(userKey + ":openTrades", openTrades);

        Map<String, Object> message = new HashMap<>();
        message.put("type", "update");
        message.put("timestamp", nowMs);
        messagingTemplate.convertAndSendToUser(uid, "/trades", message);

        kafkaTemplate.send(
                "trade.open",
                saved.getSymbol(),
                new OpenTradeEvent(
                        saved.getId(),
                        saved.getSymbol(),
                        saved.getOrderType().name(),
                        saved.getSl(),
                        saved.getTp(),
                        saved.getVolume()));

        return ResponseEntity.ok(Map.of("retcode", 10009, "trade", saved));
    }

    // MT5-style validation (null-safe)
    private boolean validateSLTP(OpenTrade trade) {
        if (trade == null)
            return true;
        OrderType ot = trade.getOrderType();
        if (ot == null)
            return true;

        Double open = trade.getOpenPrice();
        Double trigger = trade.getTriggerPrice();

        double refPrice = (open != null && open > 0) ? open : (trigger != null ? trigger : 0);
        if (refPrice == 0)
            return true;

        boolean isBuy = ot.name().startsWith("BUY");

        if (trade.getSl() != null) {
            if (isBuy && trade.getSl() >= refPrice)
                return false;
            if (!isBuy && trade.getSl() <= refPrice)
                return false;
        }
        if (trade.getTp() != null) {
            if (isBuy && trade.getTp() <= refPrice)
                return false;
            if (!isBuy && trade.getTp() >= refPrice)
                return false;
        }
        return true;
    }

    @PostMapping("/close/{id}")
    public ResponseEntity<?> closeTrade(
            @PathVariable String id,
            @RequestBody CloseTradeRequest body,
            HttpServletRequest req) {

        Optional<String> uidOpt = getUserIdSafe(req);
        if (uidOpt.isEmpty())
            return ResponseEntity.status(401).body(Map.of("retcode", 10016, "error", "Invalid token"));
        String userId = uidOpt.get();
        Optional<OpenTrade> optionalTrade = openRepo.findByUserIdAndId(userId, id);
        if (optionalTrade.isEmpty() || !optionalTrade.get().getStatus().equals(OrderStatus.OPEN)) {
            return ResponseEntity.badRequest().body("Trade not found or not open");
        }

        OpenTrade trade = optionalTrade.get();

        try {
            boolean success = tradeService.closeTradeAtomically(
                    trade,
                    body.closePrice(),
                    body.reason() != null ? body.reason() : "MANUAL"
            );

            if (success) {
                long nowMs = System.currentTimeMillis();
                String userKey = "user:" + userId;

                redisTemplate.opsForValue().set(userKey + ":lastUpdateMs", nowMs);

                List<OpenTrade> open = openRepo.findByUserId(userId);
                List<ClosedTrade> closed = closedRepo.findByUserId(userId);
                AccountService.AccountSnapshot balance = accountService.calculate(userId);

                redisTemplate.opsForValue().set(userKey + ":openTrades", open);
                redisTemplate.opsForValue().set(userKey + ":closedTrades", closed);
                redisTemplate.opsForValue().set(userKey + ":balance", balance);

                execService.removeOpenFromCache(trade.getSymbol(), trade.getId());

                Map<String, Object> message = new HashMap<>();
                message.put("type", "update");
                message.put("timestamp", nowMs);

                messagingTemplate.convertAndSendToUser(userId, "/trades", message);

                return ResponseEntity.ok("Trade closed successfully");
            } else {
                return ResponseEntity.badRequest().body("Failed to close trade");
            }

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage()); // 🔥 THIS LINE
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modifyTrade(@PathVariable String id, @RequestBody ModifyTradeRequest updates,
            HttpServletRequest req) {
        Optional<String> uidOpt = getUserIdSafe(req);
        if (uidOpt.isEmpty())
            return ResponseEntity.status(401).body(Map.of("retcode", 10016, "error", "Invalid token"));

        String uid = uidOpt.get();

        try {
            tradeService.validateUserNotBlocked(uid);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());   //addded here validation as well
        }

        OpenTrade existing = openRepo.findByUserIdAndId(uid, id)
                .orElseThrow(() -> new RuntimeException("Trade not found"));

        // Apply updates (SL/TP/volume) — DTO doesn't include openPrice so entry price
        // can't be changed here
        if (updates.sl() != null)
            existing.setSl(updates.sl());
        if (updates.tp() != null)
            existing.setTp(updates.tp());
        if (updates.volume() != null && updates.volume() > 0)
            existing.setVolume(updates.volume());

        // Re-validate (null-safe)
        if (!validateSLTP(existing)) {
            return ResponseEntity.badRequest().body(Map.of("retcode", 10014, "error", "Invalid modifications"));
        }

        OpenTrade saved = openRepo.save(existing);
        kafkaTemplate.send(
                "trade.modify",
                saved.getSymbol(),
                new ModifyTradeEvent(
                        saved.getId(),
                        saved.getSl(),
                        saved.getTp(),
                        saved.getVolume()));

        // Update cache
        execService.updateOpenInCache(saved);

        // Update Redis caches and WS
        long nowMs = System.currentTimeMillis();
        String userKey = "user:" + uid;
        redisTemplate.opsForValue().set(userKey + ":lastUpdateMs", nowMs);

        List<OpenTrade> open = openRepo.findByUserId(uid);
        List<ClosedTrade> closed = closedRepo.findByUserId(uid);
        AccountService.AccountSnapshot balance = accountService.calculate(uid);
        redisTemplate.opsForValue().set(userKey + ":openTrades", open);
        redisTemplate.opsForValue().set(userKey + ":closedTrades", closed);
        redisTemplate.opsForValue().set(userKey + ":balance", balance);

        Map<String, Object> message = new HashMap<>();
        message.put("type", "update");
        message.put("timestamp", nowMs);
        messagingTemplate.convertAndSendToUser(uid, "/trades", message);

        return ResponseEntity.ok(Map.of("retcode", 10009, "trade", saved));
    }

    @PostMapping("/{id}/partial")
    public ResponseEntity<?> partialClose(@PathVariable String id, @RequestBody PartialCloseRequest body,
            HttpServletRequest req) {
        Optional<String> uidOpt = getUserIdSafe(req);
        if (uidOpt.isEmpty())
            return ResponseEntity.status(401).body(Map.of("retcode", 10016, "error", "Invalid token"));
        String userId = uidOpt.get();

        Optional<OpenTrade> optionalTrade = openRepo.findByUserIdAndId(userId, id);
        if (optionalTrade.isEmpty() || !optionalTrade.get().getStatus().equals(OrderStatus.OPEN)) {
            return ResponseEntity.badRequest().body("Trade not found or not open");
        }

        OpenTrade trade = optionalTrade.get();

        try {
            boolean success = tradeService.partialCloseAtomically(
                    trade.getId(),
                    userId,
                    body.closeVolume(),
                    body.closePrice(),
                    "PARTIAL"
            );

            if (success) {
                long nowMs = System.currentTimeMillis();
                String userKey = "user:" + userId;

                redisTemplate.opsForValue().set(userKey + ":lastUpdateMs", nowMs);

                List<OpenTrade> open = openRepo.findByUserId(userId);
                List<ClosedTrade> closed = closedRepo.findByUserId(userId);
                AccountService.AccountSnapshot balance = accountService.calculate(userId);

                redisTemplate.opsForValue().set(userKey + ":openTrades", open);
                redisTemplate.opsForValue().set(userKey + ":closedTrades", closed);
                redisTemplate.opsForValue().set(userKey + ":balance", balance);

                execService.removeOpenFromCache(trade.getSymbol(), trade.getId());

                Map<String, Object> message = new HashMap<>();
                message.put("type", "update");
                message.put("timestamp", nowMs);

                messagingTemplate.convertAndSendToUser(userId, "/trades", message);

                return ResponseEntity.ok("Trade modified successfully");
            } else {
                return ResponseEntity.badRequest().body("Failed to modify trade");
            }

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/balance/deposit")
    public ResponseEntity<?> depositBalance(@RequestBody BalanceDepositRequest body, HttpServletRequest req) {
        String userId = body.userId();
        double amount = body.amount();
        String reason = body.reason() != null ? body.reason() : "DEPOSIT";

        UserBalance bal = balanceRepo.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No balance found for user"));

        mongoTemplate.upsert(
                new Query(Criteria.where("_id").is(userId)),
                new Update().inc("balance", amount),
                UserBalance.class);

        messagingTemplate.convertAndSendToUser(userId, "/account/update", accountService.calculate(userId));

        return ResponseEntity
                .ok(Map.of("retcode", 10009, "message", "Deposit added", "newBalance", bal.getBalance() + amount));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/credit/deposit")
    public ResponseEntity<?> depositCredit(@RequestBody CreditDepositRequest body) {
        if (body.amount() <= 0) {
            return ResponseEntity.badRequest().body("Credit amount must be positive");
        }
        String userId = body.userId();
        double amount = body.amount();
        UserBalance bal = balanceRepo.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No balance found for user"));

        mongoTemplate.upsert(
                new Query(Criteria.where("_id").is(userId)),
                new Update().inc("credit", amount),
                UserBalance.class);

        messagingTemplate.convertAndSendToUser(userId, "/account/update", accountService.calculate(userId));

        return ResponseEntity
                .ok(Map.of("retcode", 10010, "message", "Credit added", "newCredit", bal.getCredit() + amount));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/user/change-password")
    public ResponseEntity<?> adminChangeUserPassword(@RequestBody ChangePasswordRequest body, HttpServletRequest req) {
        if (body == null || body.getUserId() == null || body.getNewPassword() == null
                || body.getUserId().isBlank() || body.getNewPassword().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("retcode", 10020, "error", "Missing userId or newPassword"));
        }

        if (body.getNewPassword().length() < 8) {
            return ResponseEntity.badRequest()
                    .body(Map.of("retcode", 10021, "error", "New password must be at least 8 characters"));
        }

        String targetUserId = body.getUserId();

        Query q = new Query(Criteria.where("_id").is(targetUserId));
        Document userDoc = mongoTemplate.findOne(q, Document.class, "users");
        if (userDoc == null) {
            return ResponseEntity.status(404).body(Map.of("retcode", 10022, "error", "User not found"));
        }

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String newHash = encoder.encode(body.getNewPassword());

        String adminId = getUserIdSafe(req).orElse("unknown-admin");
        Update update = new Update()
                .set("passwordHash", newHash)
                .set("pwdChangedAt", Instant.now().toString())
                .set("pwdChangedBy", adminId);

        mongoTemplate.updateFirst(q, update, "users");

        try {
            messagingTemplate.convertAndSendToUser(targetUserId, "/account/update",
                    accountService.calculate(targetUserId));
        } catch (Exception ignored) {
        }

        return ResponseEntity.ok(Map.of("retcode", 10009, "message", "Password changed for user " + targetUserId));
    }

    @GetMapping("/admin/cache-sizes")
    public ResponseEntity<?> cacheSizes() {
        Map<String, Integer> sizes = execService.cacheSizes();
        return ResponseEntity.ok(Map.of("retcode", 10009, "cacheSizes", sizes));
    }

@DeleteMapping("/{id}/cancel")
public ResponseEntity<?> cancelPendingOrder(@PathVariable String id, HttpServletRequest req) {
    Optional<String> uidOpt = getUserIdSafe(req);
    if (uidOpt.isEmpty()) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("retcode", 10016, "error", "Invalid token"));
    }

    String userId = uidOpt.get();

    try {
        OpenTrade cancelled = tradeService.cancelPendingOrder(userId, id);

        // remove from in-memory pending cache
        execService.removePendingFromCache(cancelled.getSymbol(), cancelled.getId());

        return ResponseEntity.ok(Map.of(
                "retcode", 10009,
                "message", "Pending order cancelled",
                "trade", cancelled
        ));
    } catch (NoSuchElementException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("retcode", 10004, "error", e.getMessage()));
    } catch (IllegalStateException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("retcode", 10005, "error", e.getMessage()));
    }
}

}
