package com.app.traderss.symbols;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserWatchlistRepository extends MongoRepository<UserWatchlist, String> {
    // findById(userId) inherited
}
