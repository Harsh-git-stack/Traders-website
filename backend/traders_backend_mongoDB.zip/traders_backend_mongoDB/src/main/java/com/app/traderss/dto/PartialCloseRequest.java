package com.app.traderss.dto;

public record PartialCloseRequest(double closeVolume, double closePrice) {}