package com.app.traderss.symbols;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.Map;

@Getter
@Setter
@Document(collection = "symbols")
public class SymbolSpec {

    @Id
    private String id;
    private String symbol; // EURUSD, BTCUSD, AEDAUD

    // Basic identity
    private String name;
    private String description;
    private String type;        // FOREX, CRYPTO, INDEX, STOCK
    private String source;
    private String sourceId;
    private boolean active;
    private Instant lastUpdated;

    // Trading basics
    private String exchange;    // XCCY, XNAS, etc.
    private String sector;      // Currency, Crypto, Index, Stock
    private int digits;
    private double pipSize;
    private double tickSize;
    private double contractSize;

    // Spread / trading rules
    private String spreadType;  // Floating / Fixed
    private String spread;      // keep current value as string if your app already uses it
    private int stopLevels;
    private String marginCurrency;
    private String profitCurrency;
    private String calculation; // Forex, CFD, etc.
    private double hedgedMargin;
    private String trade;       // Full access
    private String chartMode;    // By bid price
    private String execution;    // Market Execution
    private String gtcMode;      // Good till cancelled
    private String fillPolicy;   // Fill or Kill
    private String expiration;   // All
    private String orders;       // All
    private double marginRate;
    // Volumes
    private double minimalVolume;
    private double maximalVolume;
    private double volumeStep;

    // Swaps
    private String swapType;     // In points
    private double swapLong;
    private double swapShort;

    // Nested MT5-like sections
    private Map<String, Integer> swapRates;        // monday, tuesday...
    private Map<String, String> quotesSessions;    // monday: 00:00-24:00
    private Map<String, String> tradeSessions;     // monday: 00:00-24:00

    public SymbolSpec() {
        this.active = true;
        this.lastUpdated = Instant.now();
        this.spread = "0";
        this.spreadType = "Floating";
    }
}