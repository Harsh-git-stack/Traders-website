package com.app.traderss.trades.kafka;

public record OpenTradeEvent(
        String tradeId,
        String symbol,
        String orderType,
        Double sl,
        Double tp,
        Double volume
) {}
