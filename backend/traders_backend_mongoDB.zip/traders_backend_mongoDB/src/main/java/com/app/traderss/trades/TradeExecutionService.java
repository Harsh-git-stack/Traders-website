package com.app.traderss.trades;

import com.app.traderss.trades.kafka.TickPayload;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.context.event.EventListener;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * TradeExecutionService with in-memory caches and small stability window to
 * prevent micro-spike-triggered closes/activations.
 *
 * Keep DB atomic operations in TradeService (activatePendingOrder, closeTradeAtomically).
 */
@Service
public class TradeExecutionService {

    private final OpenTradeRepository openRepo;
    private final TradeService tradeService;

    // caches: symbol -> (tradeId -> OpenTrade)
    private final ConcurrentHashMap<String, ConcurrentHashMap<String, OpenTrade>> pendingMap = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, ConcurrentHashMap<String, OpenTrade>> openMap = new ConcurrentHashMap<>();

    // stability / hit counters keyed by "<tradeId>:TP" or "<tradeId>:SL"
    private final ConcurrentHashMap<String, Integer> hitCounts = new ConcurrentHashMap<>();
    private final int requiredConsecutiveHits = 2; // tuneable

    private static final double BASE_TOLERANCE = 0.00000001;

    public TradeExecutionService(OpenTradeRepository openRepo, TradeService tradeService) {
        this.openRepo = openRepo;
        this.tradeService = tradeService;
    }

    public void removePendingFromCache(String symbol, String tradeId) {
    if (symbol == null || tradeId == null) return;
    ConcurrentHashMap<String, OpenTrade> pmap = pendingMap.get(symbol);
    if (pmap != null) {
        pmap.remove(tradeId);
    }
}

    // -----------------------
    // Startup cache load
    // -----------------------
    @EventListener(ApplicationReadyEvent.class)
    public void loadCaches() {
        System.out.println("[Startup] Loading pending/open trades into memory...");
        List<OpenTrade> pendings = openRepo.findByStatus(OrderStatus.PENDING);
        for (OpenTrade p : pendings) {
            pendingMap.computeIfAbsent(p.getSymbol(), s -> new ConcurrentHashMap<>()).put(p.getId(), p);
        }

        List<OpenTrade> opens = openRepo.findByStatus(OrderStatus.OPEN);
        for (OpenTrade o : opens) {
            openMap.computeIfAbsent(o.getSymbol(), s -> new ConcurrentHashMap<>()).put(o.getId(), o);
        }

        System.out.println("[Startup] caches loaded: pendingSymbols=" + pendingMap.size() + " openSymbols=" + openMap.size());
    }

    // -----------------------
    // Cache sync helpers (call from controllers/services that change trades)
    // -----------------------
    public void addPendingToCache(OpenTrade t) {
        if (t == null) return;
        pendingMap.computeIfAbsent(t.getSymbol(), s -> new ConcurrentHashMap<>()).put(t.getId(), t);
    }

    public void addOpenToCache(OpenTrade t) {
        if (t == null) return;
        openMap.computeIfAbsent(t.getSymbol(), s -> new ConcurrentHashMap<>()).put(t.getId(), t);
    }

    public void movePendingToOpenCache(String symbol, String tradeId) {
        if (symbol == null || tradeId == null) return;
        ConcurrentHashMap<String, OpenTrade> pmap = pendingMap.get(symbol);
        if (pmap != null) {
            OpenTrade t = pmap.remove(tradeId);
            if (t != null) {
                t.setStatus(OrderStatus.OPEN);
                openMap.computeIfAbsent(symbol, s -> new ConcurrentHashMap<>()).put(tradeId, t);
            }
        }
    }

    public void removeOpenFromCache(String symbol, String tradeId) {
        if (symbol == null || tradeId == null) return;
        ConcurrentHashMap<String, OpenTrade> omap = openMap.get(symbol);
        if (omap != null) omap.remove(tradeId);
    }

    public void updateOpenInCache(OpenTrade trade) {
        if (trade == null) return;

        String symbol = trade.getSymbol();
        String tradeId = trade.getId();

        // Remove old version if present
        removeOpenFromCache(symbol, tradeId);

        // Add updated version
        addOpenToCache(trade);
    }

    // -----------------------
    // Public hot path: allows synchronous callers (BackendTickRouter) to call directly.
    @Transactional
    public void onTick(String symbol, double bid, double ask) {
        processSymbolTick(symbol, bid, ask);
    }

    // -----------------------
    // Kafka batch listener: receives a batch of records and processes last tick per symbol
    @KafkaListener(topics = "${app.kafka.topic.ticks:market.ticks}", containerFactory = "kafkaListenerContainerFactory")
    @Transactional
    public void onTickBatch(List<ConsumerRecord<String, TickPayload>> records, Acknowledgment ack) {
        if (records == null || records.isEmpty()) {
            if (ack != null) ack.acknowledge();
            return;
        }

        // Keep only last record per symbol in this batch
        Map<String, ConsumerRecord<String, TickPayload>> latestBySymbol = new HashMap<>(128);
        for (ConsumerRecord<String, TickPayload> r : records) {
            TickPayload tick = r.value();
            String key = r.key();
            if (key == null && tick != null) {
                // fallback to payload symbol if producer didn't set message key
                key = tick.getSymbol();
                System.out.println("[WARN] Kafka record missing key; falling back to payload.symbol=" + key);
            }
            if (key == null) {
                System.err.println("[WARN] Skipping kafka record with null key and null payload.symbol");
                continue;
            }
            latestBySymbol.put(key, r); // last wins in iteration order
        }

        // System.out.println("[INFO] onTickBatch: batchSize=" + records.size() + " uniqueSymbols=" + latestBySymbol.size());

        for (Map.Entry<String, ConsumerRecord<String, TickPayload>> e : latestBySymbol.entrySet()) {
            ConsumerRecord<String, TickPayload> rec = e.getValue();
            TickPayload tick = rec.value();
            if (tick == null || tick.getSymbol() == null) {
                // System.err.println("[WARN] Skipping empty tick for key=" + e.getKey());
                continue;
            }
            try {
                processSymbolTick(tick.getSymbol(), tick.getBid(), tick.getAsk());
            } catch (Exception ex) {
                System.err.println("Error processing symbol=" + tick.getSymbol() + " : " + ex.getMessage());
                ex.printStackTrace();
            }
        }

        if (ack != null) ack.acknowledge();
    }


    private void processSymbolTick(String symbol, double bid, double ask) {
    if (symbol == null) return;

    double normBid = normalizePrice(symbol, bid);
    double normAsk = normalizePrice(symbol, ask);

    ConcurrentHashMap<String, OpenTrade> pendings = pendingMap.get(symbol);

    // STOP-LIMIT handling
    if (pendings != null && !pendings.isEmpty()) {
        for (OpenTrade p : pendings.values()) {
            if (p.getOrderType() == OrderType.BUY_STOP_LIMIT ||
                p.getOrderType() == OrderType.SELL_STOP_LIMIT) {

                boolean isBuy = p.getOrderType() == OrderType.BUY_STOP_LIMIT;
                double stop = normalizePrice(symbol, p.getTriggerPrice());
                double market = isBuy ? normAsk : normBid;

                if (p.getStatus() == OrderStatus.PENDING) {
                    boolean stopHit = isBuy ? market >= stop : market <= stop;
                    if (stopHit) {
                        p.setOrderType(isBuy ? OrderType.BUY_LIMIT : OrderType.SELL_LIMIT);
                        p.setTriggerPrice(p.getLimitPrice());
                        p.setLimitPrice(null);
                        openRepo.save(p);
                    }
                }
            }
        }
    }

    // Pending activation only
    if (pendings != null && !pendings.isEmpty()) {
        for (OpenTrade p : pendings.values()) {
            if (shouldTrigger(p, normBid, normAsk)) {
                boolean isBuy = p.getOrderType().name().startsWith("BUY");
                double execPrice = isBuy ? normAsk : normBid;

                boolean activated = tradeService.activatePendingOrder(p, execPrice);
                if (activated) {
                    pendings.remove(p.getId());
                    openMap.computeIfAbsent(symbol, s -> new ConcurrentHashMap<>())
                           .put(p.getId(), p);
                }
            }
        }
    }

    // 🔥 SL/TP REMOVED — handled by SLTP service
}


    // -----------------------
    // Helper methods (unchanged semantics)
    // -----------------------
    private boolean shouldTrigger(OpenTrade o, double bid, double ask) {
        if (o == null || o.getOrderType() == null || o.getTriggerPrice() == null) return false;
        boolean isBuy = o.getOrderType().name().startsWith("BUY");
        double executionPrice = normalizePrice(o.getSymbol(), isBuy ? bid : ask);
        double trigger = normalizePrice(o.getSymbol(), o.getTriggerPrice());

        return switch (o.getOrderType()) {
            case BUY_LIMIT -> executionPrice <= trigger;
            case SELL_LIMIT -> executionPrice >= trigger;
            case BUY_STOP -> executionPrice >= trigger;
            case SELL_STOP -> executionPrice <= trigger;
            case BUY_STOP_LIMIT, SELL_STOP_LIMIT -> false;
            default -> false;
        };
    }

    private double normalizePrice(String symbol, double price) {
        if (symbol == null) return price;
        int digits = symbol.contains("JPY") ? 3 : 5;
        double factor = Math.pow(10, digits);
        return Math.round(price * factor) / factor;
    }

    private double getTolerance(String symbol) {
        int digits = symbol != null && symbol.contains("JPY") ? 3 : 5;
        double pip = 1.0 / Math.pow(10, digits);
        return pip * 0.5; // half pip tolerance
    }

    // Helpers for other code that expects these methods
    public List<OpenTrade> getPendingTrades(String symbol) {
        ConcurrentHashMap<String, OpenTrade> map = pendingMap.get(symbol);
        if (map == null) return Collections.emptyList();
        return new ArrayList<>(map.values());
    }

    public List<OpenTrade> getOpenTrades(String symbol) {
        ConcurrentHashMap<String, OpenTrade> map = openMap.get(symbol);
        if (map == null) return Collections.emptyList();
        return new ArrayList<>(map.values());
    }

    // simple health method
    public Map<String, Integer> cacheSizes() {
        Map<String, Integer> sizes = new HashMap<>();
        sizes.put("pendingSymbols", pendingMap.size());
        sizes.put("openSymbols", openMap.size());
        return sizes;
    }
}
