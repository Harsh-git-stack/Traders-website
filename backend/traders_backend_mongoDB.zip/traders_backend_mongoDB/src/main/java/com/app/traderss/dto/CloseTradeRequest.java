package com.app.traderss.dto;


public record CloseTradeRequest(
    double closePrice,
     String reason
) {}


