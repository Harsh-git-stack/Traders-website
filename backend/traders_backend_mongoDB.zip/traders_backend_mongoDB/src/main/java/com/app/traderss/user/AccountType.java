package com.app.traderss.user;

public enum AccountType {
    DEMO,
    LIVE;

    public static AccountType fromString(String s) {
        if (s == null) return LIVE; // default
        try {
            return AccountType.valueOf(s.toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
