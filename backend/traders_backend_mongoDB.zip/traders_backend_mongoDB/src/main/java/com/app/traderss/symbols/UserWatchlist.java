package com.app.traderss.symbols;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "user_watchlists")
public class UserWatchlist {
    @Id
    private String userId;
    private List<WatchlistItem> watchlist = new ArrayList<>();
    private Instant updatedAt = Instant.now();

    public static class WatchlistItem {
        private String symbol;
        private String type;
        public WatchlistItem() {}
        public WatchlistItem(String symbol, String type) { this.symbol = symbol; this.type = type; }
        public String getSymbol(){ return symbol; }
        public void setSymbol(String s){ this.symbol = s; }
        public String getType(){ return type; }
        public void setType(String t){ this.type = t; }
    }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public List<WatchlistItem> getWatchlist() { return watchlist; }
    public void setWatchlist(List<WatchlistItem> watchlist) { this.watchlist = watchlist; }

    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}
