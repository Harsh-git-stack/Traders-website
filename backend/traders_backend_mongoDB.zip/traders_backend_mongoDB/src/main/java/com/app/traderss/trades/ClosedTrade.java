package com.app.traderss.trades;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@Document(collection = "closed_trades")
public class ClosedTrade {

    @Id
    private String id;

    private String userId;
    private String symbol;
    private String type;
    private double volume;

    private double openPrice;
    private double closePrice;   // <-- NEW
    private double result;
    private double swap;
    private double commission;

    private String openTime;     // <-- NEW (so history can show when it was opened)
    private String closeTime;

    // New MT5 Fields
    private long magicNumber = 0; // EA ID
    private String comment = ""; // Order note
    private String expiration; // ISO date for pendings

    



}
