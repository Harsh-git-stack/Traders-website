package com.app.traderss.trades;

import com.app.traderss.service.AccountService;
import com.app.traderss.symbols.SymbolRepository;
import com.app.traderss.symbols.SymbolSpec;
import com.app.traderss.user.User;
import com.app.traderss.user.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@Service
public class TradeService {

    private final OpenTradeRepository openRepo;
    private final ClosedTradeRepository closedRepo;
    private final MongoTemplate mongoTemplate;
    private final SymbolRepository symbolRepo;
    private final RedisTemplate<String, Object> redisTemplate;
    private final SimpMessagingTemplate messagingTemplate;
    private final AccountService accountService;
    private final UserRepository userRepository;

    // local JSON mapper (used to publish to redis)
    private final ObjectMapper objectMapper = new ObjectMapper();

    public TradeService(
            OpenTradeRepository openRepo,
            ClosedTradeRepository closedRepo,
            MongoTemplate mongoTemplate,
            SymbolRepository symbolRepo,
            RedisTemplate<String, Object> redisTemplate,
            SimpMessagingTemplate messagingTemplate,
            AccountService accountService,
            UserRepository userRepository   // adding the constructor
    ) {

        this.openRepo = openRepo;
        this.closedRepo = closedRepo;
        this.mongoTemplate = mongoTemplate;
        this.symbolRepo = symbolRepo;
        this.redisTemplate = redisTemplate;
        this.messagingTemplate = messagingTemplate;
        this.accountService = accountService;
        this.userRepository = userRepository;
    }

    //adding helper functionnnn
    public  void validateUserNotBlocked(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getIsBlocked() != null && user.getIsBlocked()) {
            throw new RuntimeException("User is blocked from trading");
        }
    }


    private String normalizeSymbol(String raw) {
        if (raw == null) return null;
        return raw.replaceFirst("^.+?:", "")
                  .replaceAll("[^A-Za-z0-9]", "")
                  .toUpperCase();
    }

    public void attachPipInfo(OpenTrade t) {
        if (t == null || t.getSymbol() == null) return;

        String norm = normalizeSymbol(t.getSymbol());
        SymbolSpec s = symbolRepo.findById(norm).orElse(null);

        double pipSize;
        double contractSize;

        if (s != null) {
            pipSize = s.getPipSize();
            contractSize = s.getContractSize();
        } else {
            String symbol = norm.toUpperCase();
            if (symbol.startsWith("XAU")) {
                pipSize = 0.1;
                contractSize = 100.0;
            } else if (symbol.startsWith("XAG")) {
                pipSize = 0.01;
                contractSize = 5000.0;
            } else if (symbol.contains("BTC") || symbol.contains("ETH") || symbol.contains("USDT")) {
                pipSize = 1.0;
                contractSize = 1.0;
            } else {
                pipSize = symbol.contains("JPY") ? 0.01 : 0.0001;
                contractSize = 100000.0;
            }
        }

        double volume = Math.max(0.0, t.getVolume());
        double pipValuePerLot = pipSize * contractSize;
        double pipValue = pipValuePerLot * volume;

        t.setPipSize(pipSize);
        t.setPipValuePerLot(pipValuePerLot);
        t.setPipValue(pipValue);
    }

    /* -------------------------
       Helper: notify caches & WS (backend-only reliability layer)
       ------------------------- */
    private void notifyUserCachesAndWsAfterCommit(String userId, long nowMs) {
        // If inside a Spring transaction that supports synchronization, register an afterCommit,
        // otherwise execute right away.
        Runnable notifyAction = () -> {
            try {
                // Build data and update redis snapshot key(s)
                List<OpenTrade> open = openRepo.findByUserId(userId);
                List<ClosedTrade> closed = closedRepo.findByUserId(userId);
                AccountService.AccountSnapshot balance = accountService.calculate(userId);

                String userKey = "user:" + userId;
                redisTemplate.opsForValue().set(userKey + ":lastUpdateMs", nowMs);
                redisTemplate.opsForValue().set(userKey + ":openTrades", open);
                redisTemplate.opsForValue().set(userKey + ":closedTrades", closed);
                redisTemplate.opsForValue().set(userKey + ":balance", balance);

                Map<String, Object> message = new HashMap<>();
                message.put("type", "update");
                message.put("timestamp", nowMs);

                // --- Primary delivery (existing): user-specific send ---
                try {
                    messagingTemplate.convertAndSendToUser(userId, "/trades", message);
                } catch (Exception ex) {
                    System.err.println("[notify] convertAndSendToUser failed for user=" + userId + " : " + ex.getMessage());
                }

                // --- Fallback destinations: publish to several topics that clients may be subscribed to ---
                try {
                    messagingTemplate.convertAndSend("/topic/trades/" + userId, message);
                } catch (Exception ex) {
                    System.err.println("[notify] send to /topic/trades/{user} failed: " + ex.getMessage());
                }

                try {
                    messagingTemplate.convertAndSend("/topic/trades", message); // generic broadcast (clients may ignore)
                } catch (Exception ex) {
                    // non-fatal
                }

                // Some clients subscribe to /user/queue/trades or /user/{user}/trades variants, try these too
                try {
                    messagingTemplate.convertAndSend("/user/" + userId + "/trades", message);
                } catch (Exception ex) {
                    // ignore
                }

                try {
                    messagingTemplate.convertAndSend("/user/queue/trades", message);
                } catch (Exception ex) {
                    // ignore
                }

                // --- Cross-instance reliability: publish to a Redis channel so ALL instances can re-emit locally ---
                try {
                    Map<String, Object> pub = new HashMap<>();
                    pub.put("user", userId);
                    pub.put("timestamp", nowMs);
                    pub.put("type", "update");
                    String payload = objectMapper.writeValueAsString(pub);
                    redisTemplate.convertAndSend("trade.notifications", payload);
                } catch (JsonProcessingException jex) {
                    System.err.println("[notify] failed to serialize redis payload: " + jex.getMessage());
                } catch (Exception rex) {
                    System.err.println("[notify] redis publish failed: " + rex.getMessage());
                }

            } catch (Exception e) {
                // don't allow notifications to crash the caller
                System.err.println("[TradeService.notify] failed for user=" + userId + " : " + e.getMessage());
                e.printStackTrace();
            }
        };

        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    notifyAction.run();
                }
            });
        } else {
            // no transaction support — just run the notifier immediately
            notifyAction.run();
        }
    }

    /**
     * Atomically close a full trade and notify (after commit if possible).
     */
    @Transactional
    public boolean closeTradeAtomically(OpenTrade trade, double closePrice, String reason) {
        String id = trade.getId();
        String userId = trade.getUserId();

        validateUserNotBlocked(userId);

        Query query = new Query(Criteria.where("_id").is(id)
                .and("userId").is(userId)
                .and("status").is(OrderStatus.OPEN));

        Update markUpdate = new Update().set("status", OrderStatus.CLOSED);
        OpenTrade fetchedTrade = mongoTemplate.findAndModify(query, markUpdate,
                FindAndModifyOptions.options().returnNew(false), OpenTrade.class);

        if (fetchedTrade == null) return false;

        double swap = fetchedTrade.getAccumulatedSwap();
        double commission = fetchedTrade.getAccumulatedCommission();
        double result = calculateResult(fetchedTrade, closePrice) + swap + commission;

        mongoTemplate.remove(new Query(Criteria.where("_id").is(id)), OpenTrade.class);

        ClosedTrade closed = new ClosedTrade();
        closed.setUserId(userId);
        closed.setSymbol(fetchedTrade.getSymbol());
        closed.setType(fetchedTrade.getType());
        closed.setVolume(fetchedTrade.getVolume());
        closed.setOpenPrice(fetchedTrade.getOpenPrice());
        closed.setClosePrice(closePrice);
        closed.setResult(result);
        closed.setOpenTime(fetchedTrade.getTime());
        closed.setCloseTime(Instant.now().toString());
        closed.setComment(reason);
        closed.setSwap(fetchedTrade.getAccumulatedSwap());
        closed.setCommission(fetchedTrade.getAccumulatedCommission());

        closedRepo.save(closed);

        mongoTemplate.upsert(
                new Query(Criteria.where("_id").is(userId)),
                new Update().inc("balance", result),
                UserBalance.class);

        long nowMs = System.currentTimeMillis();

        notifyUserCachesAndWsAfterCommit(userId, nowMs);

        System.out.println("🔒 ATOMIC CLOSE " + fetchedTrade.getSymbol() + " reason=" + reason + " price=" + closePrice + " result=" + result);
        return true;
    }

    /**
     * Atomically partial close: updates and notify after commit if possible.
     */
    @Transactional
    public boolean partialCloseAtomically(String id, String userId, double closeVol, double closePrice, String reason) {
        validateUserNotBlocked(userId); // added here as well
        if (closeVol <= 0) throw new IllegalArgumentException("Invalid close volume");
        if (closePrice <= 0) throw new IllegalArgumentException("Invalid close price");

        System.out.println("PARTIAL CLOSE RECEIVED closePrice=" + closePrice + " closeVol=" + closeVol + " id=" + id);

        Query query = new Query(Criteria.where("_id").is(id)
                .and("userId").is(userId)
                .and("status").is(OrderStatus.OPEN)
                .and("volume").gte(closeVol));

        OpenTrade before = mongoTemplate.findOne(query, OpenTrade.class);
        if (before == null) return false;

        double originalVol = before.getVolume();
        double remainVol = originalVol - closeVol;

        Update update = new Update().inc("volume", -closeVol);
        if (remainVol <= 0.01) update.set("status", OrderStatus.CLOSED);

        OpenTrade updated = mongoTemplate.findAndModify(query, update,
                FindAndModifyOptions.options().returnNew(true), OpenTrade.class);

        if (updated == null) return false;

        if (updated.getPipValuePerLot() != null) {
            double newPipValue = updated.getPipValuePerLot() * updated.getVolume();
            updated.setPipValue(newPipValue);
            openRepo.save(updated);
        }

        double partialResult = calculateResult(before, closePrice) * (closeVol / originalVol);

        ClosedTrade closed = new ClosedTrade();
        closed.setUserId(userId);
        closed.setSymbol(before.getSymbol());
        closed.setType(before.getType());
        closed.setVolume(closeVol);
        closed.setOpenPrice(before.getOpenPrice());
        closed.setClosePrice(closePrice);
        closed.setResult(partialResult);
        closed.setOpenTime(before.getTime());
        closed.setCloseTime(Instant.now().toString());
        closed.setComment(reason + "_PARTIAL");
        closed.setSwap(0.0);
        closed.setCommission(0.0);

        closedRepo.save(closed);

        mongoTemplate.upsert(
                new Query(Criteria.where("_id").is(userId)),
                new Update().inc("balance", partialResult),
                UserBalance.class);

        if (remainVol <= 0.01) {
            mongoTemplate.remove(new Query(Criteria.where("_id").is(id)), OpenTrade.class);
        }

        long nowMs = System.currentTimeMillis();
        notifyUserCachesAndWsAfterCommit(userId, nowMs);

        System.out.println("🔒 PARTIAL CLOSE: " + before.getSymbol() + " closedVol=" + closeVol + " result=" + partialResult);
        return true;
    }

    public boolean activatePendingOrder(OpenTrade pending, double price) {
        String id = pending.getId();
        String userId = pending.getUserId();

        Query query = new Query(Criteria.where("_id").is(id)
                .and("status").is(OrderStatus.PENDING)
                .and("userId").is(userId));

        OrderType orderType = pending.getOrderType();
        boolean isBuyType = orderType.name().startsWith("BUY");
        OrderType finalSide = isBuyType ? OrderType.BUY : OrderType.SELL;
        String typeString = isBuyType ? "buy" : "sell";

        SymbolSpec spec = symbolRepo.findById(pending.getSymbol()).orElse(null);
        Double pipSize = null;
        Double pipValuePerLot = null;
        Double pipValue = null;
        if (spec != null) {
            pipSize = spec.getPipSize();
            pipValuePerLot = pipSize * spec.getContractSize();
            pipValue = pipValuePerLot * pending.getVolume();
        }

        Update update = new Update()
                .set("status", OrderStatus.OPEN)
                .set("openPrice", price)
                .set("type", typeString)
                .set("orderType", finalSide)
                .unset("triggerPrice")
                .unset("limitPrice");

        if (pipSize != null) {
            update.set("pipSize", pipSize)
                  .set("pipValuePerLot", pipValuePerLot)
                  .set("pipValue", pipValue);
        }

        OpenTrade activated = mongoTemplate.findAndModify(query, update,
                FindAndModifyOptions.options().returnNew(true), OpenTrade.class);

        if (activated == null) return false;

        System.out.println("⚡ PENDING → OPEN " + activated.getSymbol() + " at " + price);
        return true;
    }

    /**
     * Clean P&L calculation using tickSize + contractSize
     * No old pipSize logic, no repository call
     */
    private double calculateResult(OpenTrade open, double closePrice) {

        if (open == null ) return 0.0;

        double lots = open.getVolume() != null ? open.getVolume() : 1.0;
        SymbolSpec spec = null;
        spec = symbolRepo.findById(open.getSymbol()).orElse(null);
        if (spec == null) return 0.0;
        double tickSize = spec.getTickSize();
        double contractSize = spec.getContractSize();

        if (tickSize <= 0 || contractSize <= 0) return 0.0;

        double priceDiff;

        boolean isBuy = "buy".equalsIgnoreCase(open.getType());

        priceDiff = isBuy
                ? (closePrice - open.getOpenPrice())
                : (open.getOpenPrice() - closePrice);

        // Calculate tickValue on the fly (EXACT MATCH FRONTEND)
        double tickValue = contractSize * tickSize;

        // EXACT SAME FORMULA AS FRONTEND
        return priceDiff * (tickValue / tickSize) * lots ;
    }

@Transactional
public OpenTrade cancelPendingOrder(String userId, String tradeId) {
    validateUserNotBlocked(userId); // here as well
    Query query = new Query(
        Criteria.where("_id").is(tradeId)
            .and("userId").is(userId)
            .and("status").is(OrderStatus.PENDING)
    );

    OpenTrade cancelled = mongoTemplate.findAndRemove(query, OpenTrade.class);

    if (cancelled == null) {
        throw new NoSuchElementException("Pending order not found or already executed");
    }

    long nowMs = System.currentTimeMillis();
    notifyUserCachesAndWsAfterCommit(userId, nowMs);

    return cancelled;
}
}
