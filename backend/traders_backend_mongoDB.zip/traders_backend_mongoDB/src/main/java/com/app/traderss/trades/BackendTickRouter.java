package com.app.traderss.trades;

import com.app.traderss.trades.kafka.TickPayload;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class BackendTickRouter {

    private final TradeExecutionService tradeExecutionService;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    public BackendTickRouter(TradeExecutionService tradeExecutionService,
                             KafkaTemplate<String, String> kafkaTemplate,
                             ObjectMapper objectMapper) {
        this.tradeExecutionService = tradeExecutionService;
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }

    public void routeTick(String symbol, double bid, double ask) {
        // System.out.println("🔥 BACKEND TICK: " + symbol + " " + bid + " " + ask);

        tradeExecutionService.onTick(symbol, bid, ask);

        try {
            TickPayload payload = new TickPayload(
                    symbol,
                    bid,
                    ask,
                    System.currentTimeMillis()
            );

            String json = objectMapper.writeValueAsString(payload);
            kafkaTemplate.send("market.ticks", symbol, json);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}