package com.app.traderss.trades.kafka;

public record ModifyTradeEvent(
        String tradeId,
        Double sl,
        Double tp,
        Double volume
) {}
