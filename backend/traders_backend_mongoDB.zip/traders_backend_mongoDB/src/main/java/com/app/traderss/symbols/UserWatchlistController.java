package com.app.traderss.symbols;

import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import java.util.*;
import java.time.Instant;
import com.app.traderss.jwt.*;


@RestController
@RequestMapping("/api/user/watchlist")
public class UserWatchlistController {

    private final UserWatchlistRepository watchRepo;
    private final JwtUtil jwtUtil; // adapt to your project's class

    public UserWatchlistController(UserWatchlistRepository watchRepo, JwtUtil jwtUtil) {
        this.watchRepo = watchRepo;
        this.jwtUtil = jwtUtil;
    }

    private Optional<String> getUserId(HttpServletRequest req) {
        String auth = req.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) return Optional.empty();
        try { return Optional.of(jwtUtil.extractUserId(auth.substring(7))); } catch (Exception e) { return Optional.empty(); }
    }

    @GetMapping
    public Object getWatchlist(HttpServletRequest req) {
        Optional<String> uid = getUserId(req);
        if (uid.isEmpty()) return Map.of("watchlist", Collections.emptyList());
        return watchRepo.findById(uid.get())
                .map(w -> Map.of("watchlist", w.getWatchlist(), "updatedAt", w.getUpdatedAt()))
                .orElse(Map.of("watchlist", Collections.emptyList()));
    }

    @PutMapping
    public Object putWatchlist(@RequestBody Map<String,Object> body, HttpServletRequest req) {
        Optional<String> uidOpt = getUserId(req);
        if (uidOpt.isEmpty()) return Map.of("error", "unauthenticated");
        String uid = uidOpt.get();

        List<?> raw = (List<?>) body.getOrDefault("watchlist", Collections.emptyList());
        List<UserWatchlist.WatchlistItem> items = new ArrayList<>();
        for (Object o : raw) {
            if (!(o instanceof Map)) continue;
            Map<?,?> m = (Map<?,?>) o;
            String symbol = m.get("symbol") == null ? null : m.get("symbol").toString();
            String type = m.get("type") == null ? null : m.get("type").toString();
            if (symbol != null) items.add(new UserWatchlist.WatchlistItem(symbol, type));
        }

        UserWatchlist w = watchRepo.findById(uid).orElseGet(() -> {
            UserWatchlist nw = new UserWatchlist();
            nw.setUserId(uid);
            return nw;
        });
        w.setWatchlist(items);
        w.setUpdatedAt(Instant.now());
        watchRepo.save(w);
        return Map.of("ok", true, "watchlist", items);
    }
}
