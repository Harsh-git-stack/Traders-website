package com.app.traderss.service;

import com.app.traderss.trades.UserBalance;
import com.app.traderss.trades.UserBalanceRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserBalanceRepository balanceRepo;

    public UserService(UserBalanceRepository balanceRepo) {
        this.balanceRepo = balanceRepo;
    }

    public void initializeBalance(String userId, double initialBalance) {
        balanceRepo.findByUserId(userId).orElseGet(() -> {
            UserBalance newBalance = new UserBalance(userId, initialBalance, 0);
            return balanceRepo.save(newBalance);
        });
    }
}
