package com.app.traderss.trades;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class MarginService {

    private final OpenTradeRepository openRepo;
    private final UserBalanceRepository balanceRepo; // Now resolved

    public MarginService(OpenTradeRepository openRepo, UserBalanceRepository balanceRepo) {
        this.openRepo = openRepo;
        this.balanceRepo = balanceRepo;
    }

    public double calculateEquity(String userId) {
        Optional<Double> balanceOpt = balanceRepo.findBalanceByUserId(userId); // Handle Optional
        double balance = balanceOpt.orElse(0.0);
        List<OpenTrade> opens = openRepo.findByUserId(userId);
        double unrealized = opens.stream()
                .mapToDouble(t -> t.getProfit()) // Assume updated on ticks
                .sum();
        return balance + unrealized;
    }

    public boolean hasSufficientMargin(String userId, double volume, String symbol) {
        double equity = calculateEquity(userId);
        double marginPerLot = getMarginPerLot(symbol); // e.g., 1000 for EURUSD
        double required = volume * marginPerLot;
        return equity >= required * 1.05; // 5% buffer, MT5-like
    }

    private double getMarginPerLot(String symbol) {
        // Stub: Fetch from config or DB
        return symbol.startsWith("EUR") ? 1000.0 : 5000.0; // Example
    }
}