package com.app.traderss.symbols;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class SymbolSpecDefaults {

    public static SymbolSpec buildForexDefaults(String symbol, String name, String sourceId) {
        SymbolSpec spec = new SymbolSpec();

        spec.setSymbol(symbol);
        spec.setName(name);
        spec.setDescription(name);
        spec.setType("FOREX");
        spec.setSource("massive");
        spec.setSourceId(sourceId);
        spec.setActive(true);
        spec.setLastUpdated(Instant.now());

        spec.setExchange("XCCY");
        spec.setSector("Currency");
        // spec.setDigits(symbol != null && symbol.contains("JPY") ? 3 : 5);
        // spec.setPipSize(spec.getDigits() == 3 ? 0.001 : 0.0001);
        // spec.setContractSize(100000);
        if (symbol != null && symbol.startsWith("XAU")) {
            // GOLD
            spec.setDigits(2);
            spec.setPipSize(0.01);
            spec.setContractSize(100);

        } else if (symbol != null && symbol.startsWith("XAG")) {
            // SILVER
            spec.setDigits(3);
            spec.setPipSize(0.001);
            spec.setContractSize(5000);

        } else if (symbol != null && symbol.contains("JPY")) {
            // JPY PAIRS
            spec.setDigits(3);
            spec.setPipSize(0.01);
            spec.setContractSize(100000);

        } else {
            // NORMAL FOREX
            spec.setDigits(5);
            spec.setPipSize(0.0001);
            spec.setContractSize(100000);
        }

        spec.setSpreadType("Floating");
        spec.setSpread("0");
        spec.setStopLevels(0);
        spec.setMarginCurrency(symbol != null && symbol.length() >= 3 ? symbol.substring(0, 3) : "USD");
        spec.setProfitCurrency(symbol != null && symbol.length() >= 6 ? symbol.substring(3, 6) : "USD");
        spec.setCalculation("Forex");
        spec.setHedgedMargin(100000);
        spec.setTrade("Full access");
        spec.setChartMode("By bid price");
        spec.setExecution("Market Execution");
        spec.setGtcMode("Good till cancelled");
        spec.setFillPolicy("Fill or Kill");
        spec.setExpiration("All");
        spec.setOrders("All");

        spec.setMinimalVolume(0.01);
        spec.setMaximalVolume(500);
        spec.setVolumeStep(0.01);

        spec.setSwapType("In points");
        spec.setSwapLong(-0.7);
        spec.setSwapShort(-1);

        Map<String, Integer> swapRates = new LinkedHashMap<>();
        swapRates.put("monday", 1);
        swapRates.put("tuesday", 1);
        swapRates.put("wednesday", 3);
        swapRates.put("thursday", 1);
        swapRates.put("friday", 1);
        spec.setSwapRates(swapRates);

        Map<String, String> sessions = new LinkedHashMap<>();
        sessions.put("monday", "00:00-24:00");
        sessions.put("tuesday", "00:00-24:00");
        sessions.put("wednesday", "00:00-24:00");
        sessions.put("thursday", "00:00-24:00");
        sessions.put("friday", "00:00-24:00");

        spec.setQuotesSessions(sessions);
        spec.setTradeSessions(new LinkedHashMap<>(sessions));

        return spec;
    }

    public static SymbolSpec buildCryptoDefaults(String symbol, String name, String sourceId) {
        SymbolSpec spec = new SymbolSpec();

        spec.setSymbol(symbol);
        spec.setName(name);
        spec.setDescription(name);
        spec.setType("CRYPTO");
        spec.setSource("massive");
        spec.setSourceId(sourceId);
        spec.setActive(true);
        spec.setLastUpdated(Instant.now());

        spec.setExchange("CRYPTO");
        spec.setSector("Crypto");
        spec.setDigits(2);
        spec.setPipSize(0.01);
        spec.setContractSize(1);

        spec.setSpreadType("Floating");
        spec.setSpread("0");
        spec.setStopLevels(0);
        spec.setMarginCurrency("USD");
        spec.setProfitCurrency("USD");
        spec.setCalculation("CFD");
        spec.setHedgedMargin(1);
        spec.setTrade("Full access");
        spec.setChartMode("By bid price");
        spec.setExecution("Market Execution");
        spec.setGtcMode("Good till cancelled");
        spec.setFillPolicy("Fill or Kill");
        spec.setExpiration("All");
        spec.setOrders("All");

        spec.setMinimalVolume(0.01);
        spec.setMaximalVolume(500);
        spec.setVolumeStep(0.01);

        spec.setSwapType("In points");
        spec.setSwapLong(0);
        spec.setSwapShort(0);

        Map<String, Integer> swapRates = new LinkedHashMap<>();
        swapRates.put("monday", 0);
        swapRates.put("tuesday", 0);
        swapRates.put("wednesday", 0);
        swapRates.put("thursday", 0);
        swapRates.put("friday", 0);
        spec.setSwapRates(swapRates);

        Map<String, String> sessions = new LinkedHashMap<>();
        sessions.put("monday", "00:00-24:00");
        sessions.put("tuesday", "00:00-24:00");
        sessions.put("wednesday", "00:00-24:00");
        sessions.put("thursday", "00:00-24:00");
        sessions.put("friday", "00:00-24:00");

        spec.setQuotesSessions(sessions);
        spec.setTradeSessions(new LinkedHashMap<>(sessions));

        return spec;
    }
}