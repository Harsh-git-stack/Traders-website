package com.app.traderss.auth;

import com.app.traderss.dto.RegisterRequest;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Getter
@Setter
@Document(collection = "pending_registrations")
public class PendingRegistration {

    @Id
    private String id;

    @Indexed(unique = true)
    private String email;

    private String name;
    private String phone;
    private String password;
    private String role;
    private String accountType;
    private String brokerAccountType;
    private Boolean swap;
    private String otpHash;
    private Instant createdAt = Instant.now();

    @Indexed(expireAfterSeconds = 0)
    private Instant expiresAt;

    public RegisterRequest toRegisterRequest() {
        return new RegisterRequest(name, phone, email, password, role, accountType, brokerAccountType, swap);
    }
}
