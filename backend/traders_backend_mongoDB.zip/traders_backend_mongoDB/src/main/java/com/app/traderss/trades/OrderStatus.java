package com.app.traderss.trades;

public enum OrderStatus {
    PENDING,
    OPEN,
    CLOSED,
    CANCELLED
}

